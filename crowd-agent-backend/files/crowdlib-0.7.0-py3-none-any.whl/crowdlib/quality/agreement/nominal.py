from __future__ import annotations

import logging
from typing import Union

import numpy as np
import pandas as pd

from crowdlib.quality.agreement._base import AgreementBase
from crowdlib.quality.agreement._fleiss_kappa import fleiss_kappa

logger = logging.getLogger(__name__)


class NominalAgreement(AgreementBase):
    """
    Nominal Agreement(Fleiss' kappa) 计算：计算多个评分者对同一问题(选择题)的评分一致性。

    下面是一个单选题的使用方法。

    Note:
        这里的`label_set`和`df_table`的`label`字段是兼容`list`的，
        不过后续建议用`tuple`而不是`list`，这样可以更好地避免对应的数据被意外变更。


    Examples:
        >>> import pandas as pd
        >>> from crowdlib.quality.agreement import NominalAgreement
        >>> # Example data
        >>> columns = ['qid', 'uid', 'label']
        >>> rows = [
        ...     ['00', 0, ('0', )],
        ...     ['00', 1, ('0', )],
        ...     ['00', 2, ('1', )],
        ...     ['01', 0, ('0', )],
        ...     ['01', 1, ('0', )],
        ...     ['01', 2, ('1', )],
        ... ]
        >>> df_table = pd.DataFrame(rows, columns=columns)
        >>> nominal_agreement = NominalAgreement(label_set=('0', '1'))
        >>> nominal_agreement.cal_agreement(df_table)
        -0.5000000000000001
        >>> nominal_agreement.cal_agreement_contribution(df_table, target_uid=1)
        (-0.5000000000000001, -1.0)

    对于多选题也是一样：

    Examples:
        >>> import pandas as pd
        >>> from crowdlib.quality.agreement import NominalAgreement
        >>> # Example data
        >>> columns = ['qid', 'uid', 'label']
        >>> rows = [
        ...     ['00', 0, ('A', 'B')],
        ...     ['00', 1, ('A', )],
        ...     ['00', 2, ('B', 'C')],
        ...     ['01', 0, ('C', )],
        ...     ['01', 1, ('C', 'D')],
        ...     ['01', 2, ('D', )],
        ...     ['02', 0, ('A', )],
        ...     ['02', 1, ('A', 'B')],
        ...     ['02', 2, ('A', )],
        ... ]
        >>> df_table = pd.DataFrame(rows, columns=columns)
        >>> nominal_agreement = NominalAgreement(label_set=('A', 'B', 'C', 'D'))
        >>> nominal_agreement.cal_agreement(df_table)
        0.0918943533697631
        >>> nominal_agreement.cal_agreement_contribution(df_table, target_uid=1)
        (0.0918943533697631, 0.1497584541062802)

    """

    def __init__(self, label_set: Union[list, tuple]):
        super().__init__(label_set)

    def cal_agreement(self, df_table: pd.DataFrame) -> float:
        """Calculate nominal agreement within a pd.Dataframe.

        Args:
            df_table: Dataset with columns [`qid`, `uid`, `label`], the `uid` column is optional.
            The label could be int or str type.

        Returns:
            agreement: Fleiss's kappa statistic for inter rater agreement
        """

        self._validate_agreement_input_dataframe(df_table)

        table = self._aggregate_table(df_table)
        agreement = float(np.clip(fleiss_kappa(table), -1, 1))
        return agreement

    def _aggregate_table(self, df_table: pd.DataFrame) -> np.ndarray:
        """Convert raw dataframe with columns (qid, uid, label) to array with shape (n_qid, n_cat),
        brings data into correct format for fleiss_kappa.

        Args:
            df_table: pandas.Dataframe, header: (`qid`, `uid`, `label`)

        Returns:
            agg_table: numpy.array, (n_qid, n_cat)
        """

        label_set = np.array(self.label_set, dtype=str)

        # generate a map containing mapping relation between
        # original label to int label.
        label_int_map = dict(zip(label_set, range(len(label_set))))

        qid_list = df_table["qid"].unique()
        n_rows = len(qid_list)
        n_cat = len(label_set)
        agg_table = np.zeros((n_rows, n_cat), int)
        for irow, qid in enumerate(qid_list):
            qid_table = df_table[df_table["qid"] == qid]
            ans_row = np.concatenate(qid_table["label"].values, axis=None)
            # convert all label to the corresponding int values
            ans_row = [label_int_map[_ans] for _ans in ans_row]
            row_count = np.bincount(ans_row)
            agg_table[irow, : len(row_count)] = row_count

        return agg_table


if __name__ == "__main__":
    rows = [
        ["00", 0, ("0",)],
        ["00", 1, ("0",)],
        ["00", 2, ("1",)],
        ["01", 0, ("0",)],
        ["01", 1, ("0",)],
        ["01", 2, ("1",)],
        ["02", 0, ("0",)],
        ["02", 1, ("1",)],
        ["02", 2, ("0",)],
    ]
    df_table = pd.DataFrame(rows, columns=["qid", "uid", "label"])
    print(df_table)

    nominal_agreement = NominalAgreement(label_set=("0", "1"))
    print(nominal_agreement.cal_agreement(df_table))
    print(nominal_agreement.cal_agreement_contribution(df_table, target_uid=2))
