from __future__ import annotations

import json
import logging
from typing import Optional

from requests import Response

from crowdlib.service.infra.danlu._openapi import OpenApiRequest
from crowdlib.service.infra.danlu.base import DanluOpsBase, ServiceOpsResult
from crowdlib.service.infra.danlu.util import handle_http_response

logger = logging.getLogger(__name__)


class DanluTrainingTaskOps(DanluOpsBase):
    """
    丹炉训练任务: 创建、查询、停止任务
    """

    def __init__(self, access_key: str, access_secret: str, task_id: Optional[int] = None) -> None:
        super().__init__(access_key=access_key, access_secret=access_secret)
        self._task_id = task_id

    @property
    def task_id(self) -> int:
        if self._task_id is None:
            raise ValueError("task_id is not set")
        return self._task_id

    @task_id.setter
    def task_id(self, task_id: int) -> None:
        self._task_id = task_id

    def create_task(self, request_body: dict) -> ServiceOpsResult:
        """
        创建训练任务

        Args:
            request_body (dict): 请求体,请求格式参考丹炉[OpenAPI文档](http://qa-tool.fuxi.netease.com:9000/html/web/controller/share/share.html#62e90d0b2c567a00e0c28f1a)
        """
        resp = self._create_task(request_body=request_body)
        return ServiceOpsResult(status_code=resp.status_code, data=resp.json())

    def stop_task(self) -> ServiceOpsResult:
        """
        停止训练任务
        """
        resp = self._stop_task()
        return ServiceOpsResult(status_code=resp.status_code, data=resp.json)

    def get_task_info(self) -> ServiceOpsResult:
        """
        查询训练任务全部信息
        """
        resp = self._get_task_info()
        return ServiceOpsResult(status_code=resp.status_code, data=resp.json())

    def get_task_status(self) -> str:
        """
        查询训练任务状态
        """
        get_info_ops_result = self.get_task_info()
        return self._parse_task_status(get_info_ops_result.data)

    @handle_http_response(expected_status_codes=[200])
    def _get_task_info(self) -> Response:
        openapi_request = OpenApiRequest(
            self.signer,
            method="GET",
            url=f"{self.api_host}/api/v1/tasks/{self.task_id}",
            headers={"Content-Type": "application/json"},
        )
        response = openapi_request.request()
        return response

    @handle_http_response(expected_status_codes=[201, 202])
    def _stop_task(self) -> Response:
        openapi_request = OpenApiRequest(
            self.signer,
            method="DELETE",
            url=f"{self.api_host}/api/v1/tasks/{self.task_id}",
            headers={"Content-Type": "application/json"},
        )
        response = openapi_request.request()
        return response

    @handle_http_response(expected_status_codes=[201, 202])
    def _create_task(self, request_body: dict) -> Response:
        openapi_request = OpenApiRequest(
            self.signer,
            method="POST",
            url=f"{self.api_host}/api/v1/tasks",
            headers={"Content-Type": "application/json"},
            body=json.dumps(request_body).encode("utf-8"),
        )
        response = openapi_request.request()
        return response

    @staticmethod
    def _parse_task_status(task_info: dict) -> str:
        return task_info.get("status", "null")


if __name__ == "__main__":
    import logging

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler()],
    )

    ACCESS_KEY = "xxx"
    ACCESS_SECRET = "xxx"

    ops = DanluTrainingTaskOps(
        access_key=ACCESS_KEY,
        access_secret=ACCESS_SECRET,
        task_id=408704,
    )

    resp = ops.get_task_info()
    print(resp)
