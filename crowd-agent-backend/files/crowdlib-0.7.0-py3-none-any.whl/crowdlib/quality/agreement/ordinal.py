from __future__ import annotations

import logging
from typing import Union

import numpy as np
import pandas as pd

from crowdlib.quality.agreement._base import AgreementBase

logger = logging.getLogger(__name__)


class OrdinalAgreement(AgreementBase):
    """
    Ordinal Agreement 计算：计算多个评分者对同一问题(数值题)的评分一致性。

    下面是一维数值题的使用方法:

    Note:
        这里的`label_set`和`df_table`的`label`字段是兼容`list`的，
        不过后续建议用`tuple`而不是`list`，这样可以更好地避免对应的数据被意外变更。

    Examples:
        >>> import pandas as pd
        >>> from crowdlib.quality.agreement import OrdinalAgreement
        >>> # Example data
        >>> columns = ['qid', 'uid', 'label']
        >>> rows = [
        ...     ['00', 0, ('0', )],
        ...     ['00', 1, ('0', )],
        ...     ['00', 2, ('1', )],
        ...     ['01', 0, ('0', )],
        ...     ['01', 1, ('0', )],
        ...     ['01', 2, ('1', )],
        ... ]
        >>> df_table = pd.DataFrame(rows, columns=columns)
        >>> ordinal_agreement = OrdinalAgreement(label_set=('0', '1'))
        >>> ordinal_agreement.cal_agreement(df_table)
        0.8007374029168081
        >>> ordinal_agreement.cal_agreement_contribution(df_table, target_uid=1)
        (0.8007374029168081, 0.7788007830714049)

    对于多维数值题也是一样:

    Examples:
        >>> import pandas as pd
        >>> from crowdlib.quality.agreement import OrdinalAgreement
        >>> # Example data
        >>> columns = ['qid', 'uid', 'label']
        >>> rows = [
        ...     ['00', 0, ('1', '2', '3')],
        ...     ['00', 1, ('1', '2', '3')],
        ...     ['00', 2, ('1', '1', '4')],
        ...     ['01', 0, ('2', '2', '4')],
        ...     ['01', 1, ('2', '2', '4')],
        ...     ['01', 2, ('2', '2', '4')],
        ...     ['02', 0, ('0', '3', '1')],
        ...     ['02', 1, ('0', '3', '4')],
        ...     ['02', 2, ('0', '3', '1')],
        ... ]
        >>> df_table = pd.DataFrame(rows, columns=columns)
        >>> ordinal_agreement = OrdinalAgreement(label_set=('0', '1', '2', '3', '4'))
        >>> ordinal_agreement.cal_agreement(df_table)
        0.7621553000115718
        >>> ordinal_agreement.cal_agreement_contribution(df_table, target_uid=1)
        (0.7621553000115718, 0.9459594689067654)

    """

    def __init__(self, label_set: Union[list, tuple]):
        super().__init__(label_set)

    def cal_agreement(self, df_table: pd.DataFrame) -> float:
        """计算 pd.DataFrame 中的一致性。

        Args:
            df_table: 包含 [`qid`, `uid`, `label`] 列的数据集，其中 label 应为数值类型(`int`/`float`)

        Returns:
            agreement: 根据维度值的方差计算得出的一致性分数。
        """
        # 验证输入数据格式
        self._validate_agreement_input_dataframe(df_table)

        # 获取所有唯一的问题ID
        question_ids = df_table["qid"].unique()

        # 验证标签格式并获取维度数
        labels = df_table["label"].values
        dim_count = self._validate_labels(np.array(labels))

        # 计算每个维度的方差
        row_variances = self._calculate_variances(df_table, question_ids, dim_count)

        # 计算最终的一致性得分
        var_mean = np.mean(row_variances) if row_variances else 0
        return float(np.clip(np.exp(-var_mean), 0, 1))

    @staticmethod
    def _validate_labels(labels: np.ndarray) -> int:
        """验证标签格式并返回维度数"""
        if not isinstance(labels[0], (tuple, list, np.ndarray)):
            raise ValueError("Labels must be array-like objects")

        dim_count = len(labels[0])
        if not all(len(label) == dim_count for label in labels if label is not None):
            raise ValueError("All labels must have the same length. Found inconsistent shapes.")

        return dim_count

    @staticmethod
    def _calculate_variances(df_table: pd.DataFrame, question_ids: np.ndarray, dim_count: int) -> list:
        """计算每个维度的方差"""
        row_variances = []

        for qid in question_ids:
            qid_table = df_table[df_table["qid"] == qid]
            try:
                label_matrix = np.vstack(qid_table["label"].values)
                # 计算每个维度的方差
                for col_idx in range(dim_count):
                    numeric_column = np.asarray(label_matrix[:, col_idx], dtype=float)
                    if np.isnan(numeric_column).all():
                        raise ValueError("Labels are all non-numeric or NaN values")

                    row_variances.append(np.nanvar(numeric_column))

            except ValueError as e:
                raise ValueError(f"Error processing qid {qid}: {str(e)}")
            except Exception as e:
                raise Exception(f"Unexpected error for qid {qid}: {str(e)}")

        return row_variances


if __name__ == "__main__":
    rows = [
        ["00", 0, ("0",)],
        ["00", 1, ("0",)],
        ["00", 2, ("1",)],
        ["01", 0, ("0",)],
        ["01", 1, ("0",)],
        ["00", 2, ("1",)],
    ]
    df_table = pd.DataFrame(rows, columns=["qid", "uid", "label"])
    ordinal_agreement = OrdinalAgreement(label_set=("0", "1"))

    # rows = [
    #         ['00', 0, ('1', '2', '3')],
    #         ['00', 0, ('1', '2', '3')],
    #         ['00', 1, ('1', '1', '4')],
    #         ['01', 0, ('2', '2', '4')],
    #         ['01', 0, ('2', '2', '4')],
    #         ['01', 1, ('2', '2', '4')],
    #         ['02', 0, ('0', '3', '1')],
    #         ['02', 0, ('0', '3', '1')],
    #         ['02', 1, ('0', '3', '4')],
    #         ['02', 0, ('0', '3', '1')]
    #     ]
    # df_table = pd.DataFrame(rows, columns=["qid", "uid", "label"])
    # ordinal_agreement = OrdinalAgreement(label_set=('0', '1', '2', '3', '4'))

    print(df_table)
    print(ordinal_agreement.cal_agreement(df_table))
    print(ordinal_agreement.cal_agreement_contribution(df_table, target_uid=1))
