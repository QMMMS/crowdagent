from __future__ import annotations

import hmac
from datetime import datetime
from hashlib import sha256
from typing import Optional
from urllib.parse import quote, urlsplit

import requests

ALGORITHM = "OPENAPI-HMAC-SHA256"
EMPTY_SHA256_HASH = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%SZ"


class Signer:
    def __init__(self, access_key, secret_key):
        """
        Args:
            access_key: access_key issued by OPENAPI
            secret_key: secret_key issued by OPENAPI

        """
        self.access_key = access_key
        self.secret_key = secret_key

    @staticmethod
    def get_canonical_uri(request):
        uri = urlsplit(request.url).path
        if not uri:
            return "/"
        canonical_uri = quote(uri, safe="/")
        return canonical_uri

    @staticmethod
    def get_canonical_query_string(request):
        # 兼容两种URL QUERY参数指定方式
        if request.params:
            # QUERY参数 in request.param
            query_pairs = []
            for key in sorted(request.params):
                query_pairs.append("{}={}".format(quote(key, safe=""), quote(request.params.get(key, ""), safe="")))
            canonical_query_string = "&".join(query_pairs)
            return canonical_query_string
        else:
            # QUERY参数 in request.url
            url_breakdown = urlsplit(request.url)
            canonical_query_string = ""
            if url_breakdown.query:
                query_tuples = []
                for pair in url_breakdown.query.split("&"):
                    key, _, value = pair.partition("=")
                    query_tuples.append((key, value))
                query_pairs = []
                for key, value in sorted(query_tuples):
                    query_pairs.append("{}={}".format(quote(key, safe=""), quote(value, safe="")))
                canonical_query_string = "&".join(query_pairs)
            return canonical_query_string

    @staticmethod
    def get_canonical_headers(request, headers_to_sign):
        canonical_headers = []
        for header, val in request.headers.items():
            if header in headers_to_sign:
                canonical_headers.append("{}:{}".format(header.lower(), val))
        canonical_headers.sort()
        return "\n".join(canonical_headers)

    @staticmethod
    def get_signed_headers(headers_to_sign):
        signed_headers = [header.lower().strip() for header in headers_to_sign]
        signed_headers = sorted(signed_headers)
        return ";".join(signed_headers)

    @staticmethod
    def get_hashed_body(request_body):
        if request_body:
            return sha256(request_body).hexdigest()
        else:
            return EMPTY_SHA256_HASH

    def get_canonical_request(self, request, headers_to_sign):
        # HTTPRequestMethod
        canonical_request = [request.method.upper()]
        # CanonicalURI
        canonical_uri = self.get_canonical_uri(request)
        canonical_request.append(canonical_uri)
        # CanonicalQueryString
        canonical_query_string = self.get_canonical_query_string(request)
        canonical_request.append(canonical_query_string)
        # CanonicalHeaders
        canonical_headers = self.get_canonical_headers(request, headers_to_sign)
        canonical_request.append(canonical_headers)
        # SignedHeaders
        signed_headers = self.get_signed_headers(headers_to_sign)
        canonical_request.append(signed_headers)
        # HashedRequestPayload
        hashed_body = self.get_hashed_body(request.body)
        canonical_request.append(hashed_body)
        return "\n".join(canonical_request)

    @staticmethod
    def hmac_sign(key, msg, hex_=False):
        if hex_:
            signature = hmac.new(key, msg.encode("utf-8"), sha256).hexdigest()
        else:
            signature = hmac.new(key, msg.encode("utf-8"), sha256).digest()  # type: ignore
        return signature

    def get_signature(self, string_to_sign, timestamp):
        key = self.secret_key.encode("utf-8")
        # 派生密钥
        derived_key = self.hmac_sign(key, timestamp)
        return self.hmac_sign(derived_key, string_to_sign, hex_=True)

    def inject_signature_to_request(self, request, headers_to_sign, timestamp, signature):
        auth_token = "{}/{}/{}/{}/{}".format(
            ALGORITHM,
            self.access_key,
            timestamp,
            self.get_signed_headers(headers_to_sign),
            signature,
        )
        if "AUTH-TOKEN" in request.headers:
            del request.headers["AUTH-TOKEN"]
        request.headers["AUTH-TOKEN"] = auth_token

    def sign(self, request, headers_to_sign):
        datetime_now = datetime.utcnow()
        # 请求时间戳
        timestamp = datetime_now.strftime(TIMESTAMP_FORMAT)
        # 规范化的标准请求
        canonical_request = self.get_canonical_request(request, headers_to_sign)
        # 标准请求哈希值
        hashed_canonical_request = sha256(canonical_request.encode("utf-8")).hexdigest()
        # 待签名的字符串(包含Algorithm, 发送请求时间戳, 标准请求的哈希值)
        string_to_sign = "\n".join([ALGORITHM, timestamp, hashed_canonical_request])
        # 签名
        signature = self.get_signature(string_to_sign, timestamp)
        # 将签名放到request "AUTH-TOKEN"头
        self.inject_signature_to_request(request, headers_to_sign, timestamp, signature)


class OpenApiRequest:
    def __init__(
        self,
        signer: Signer,
        method: str,
        url: str,
        headers: Optional[dict] = None,
        params: Optional[dict] = None,
        body: Optional[dict | bytes] = None,
    ):
        """
        Args:
            signer: Signer instance
            method: HTTP method
            url: request url
            headers: request headers, must include the 'host' header
            params: optional, URI encoded parameters can be included in the url
            body: request body payload
        """
        self.signer = signer
        self.method = method
        # url无需进行URL编码
        self.url = url
        self.headers = headers if headers else {}
        self.params = params if params else {}
        self.body = body

    def request(self, headers_to_sign=None):
        headers_to_sign = headers_to_sign if headers_to_sign else []
        # 请求签名（注入AUTH-TOKEN头）
        self.signer.sign(self, headers_to_sign)
        return requests.request(
            self.method,
            self.url,
            headers=self.headers,
            params=self.params,
            data=self.body,
        )
