from __future__ import annotations

from pydantic import Field

from crowdlib.learn.base import LearnConfig


class TrainerConfig(LearnConfig):
    """Configuration for the IRT model training"""

    lr: float = 0.001
    """Learning rate for the optimizer."""
    n_epochs: int = 20
    """Number of training epochs."""
    batch_size: int = 512
    """Batch size for training."""
    val_ratio: float = 0.1
    """The ratio of held-out validation set for model selection, should be in (0, 1)."""
    val_freq: int = 1
    """Perform one validation and model selection every N training epochs."""


class EvaluatorConfig(LearnConfig):
    """Configuration for the IRT model evaluation"""

    batch_size: int = 256
    """Batch size for evaluation."""


class IRTConfig(LearnConfig):
    """Configuration for the IRT model"""

    device: str = "cpu"
    """Device to use for training and evaluation, either "cpu" or "cuda"."""
    trainer: TrainerConfig = Field(default_factory=TrainerConfig)
    """Configuration for the IRT model training."""
    evaluator: EvaluatorConfig = Field(default_factory=EvaluatorConfig)
    """Configuration for the IRT model evaluation."""
