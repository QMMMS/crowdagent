from __future__ import annotations

import csv
import logging
import os
from typing import Iterator, Literal, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import accuracy_score, roc_auc_score
from torch.func import functional_call
from torch.utils.data import DataLoader
from tqdm import tqdm

from crowdlib.learn.irt.config import EvaluatorConfig, TrainerConfig
from crowdlib.learn.irt.dataset import IRTDataset, IRTLogDataset, KnowledgeHierarchy
from crowdlib.learn.irt.evaluator import Evaluator
from crowdlib.learn.irt.net import (
    HierarchicalItemResponseTheoryNet,
    ItemResponseTheoryNet,
)

logger = logging.getLogger(__name__)


class IRTTrainResult:
    r"""Wrapper class that can return the training results

    Note:
        The output user parameters of the class represents the **absolute** ability
        rather than relative bias. Refer to `HierarchicalItemResponseTheoryNet`.
    """

    def __init__(self, data: IRTDataset, user_param_dict, item_param_dict) -> None:
        self._data = data
        self._user_params = user_param_dict["user_params"].detach().cpu().numpy()
        self._item_params = item_param_dict["item_params.weight"].detach().cpu().numpy()

        assert self._user_params.shape[-1] == 1
        self._user_params = self._user_params.squeeze(-1)
        self.num_users, self.num_nodes = self._user_params.shape
        self.user_id_map = data.meta.user_ids
        assert self.num_users == len(self.user_id_map)
        self.knowledge_hierarchy = KnowledgeHierarchy(data)
        assert self.num_nodes == self.knowledge_hierarchy.get_node_num()
        self.depth = self.knowledge_hierarchy.get_depth()

        assert self._item_params.ndim == 2 and self._item_params.shape[1] == 1, f"Wrong shape {self._item_params.shape}"
        self.num_items = self._item_params.shape[0]
        self.item_id_map = self._data.meta.item_ids
        assert self.num_items == len(self.item_id_map)

    def _user_ability_iter(self, node_type: Literal["capability", "task"]) -> Iterator[tuple[str, str, float]]:
        """An internal function to support stream output for multiple node types

        Args:
            node_type: the type of nodes on which , should be "task" or "capability"

        Returns:
            A generator giving (user_id, task_id, user_ability) if `node_type` == "task"
            or giving (user_id, capability_id, user_ability) if `node_type` == "capability"
        """
        assert node_type in ("capability", "task")
        for user_idx in range(self.num_users):
            user_id = self.user_id_map[user_idx]
            for node_idx in range(self.num_nodes):
                node = self.knowledge_hierarchy.get_node_by_index(node_idx)
                path = self.knowledge_hierarchy.get_node_path_by_index(node_idx)
                level = node.level
                assert len(path) == level + 1
                node_id = node.knowledge_id if level > 0 else "0"  # special id for the root
                # ability_param = self._user_params[user_idx, node_idx].astype(float)
                ability_param = sum(self._user_params[user_idx, i].astype(float) for i in path)
                if node_type == "task" and level == self.depth - 1:  # a task
                    yield user_id, node_id, ability_param
                elif node_type == "capability" and level < self.depth - 1:  # a capability
                    yield user_id, node_id, ability_param

    def user_task_iter(self) -> Iterator[tuple[str, str, float]]:
        """
        Returns:
            A generator giving (user_id, task_id, user_ability)
        """
        return self._user_ability_iter(node_type="task")

    def user_capability_iter(self) -> Iterator[tuple[str, str, float]]:
        """
        Returns:
            A generator giving (user_id, capability_id, user_ability)
        """
        return self._user_ability_iter(node_type="capability")

    def item_difficulty_iter(self) -> Iterator[tuple[str, float]]:
        for item_idx in range(self.num_items):
            yield self.item_id_map[item_idx], self._item_params[item_idx, 0].astype(float)

    def user_task_dict(self) -> dict[str, dict[str, float]]:
        """
        Returns:
            A nested dict `{ <user_id>: { <task_id>: <user_ability> } }`
        """
        user_task_dict: dict[str, dict[str, float]] = {}
        for user_id, task_id, user_ability in self.user_task_iter():
            user_task_dict.setdefault(user_id, {})
            user_task_dict[user_id][task_id] = user_ability
        return user_task_dict

    def user_capability_dict(self) -> dict[str, dict[str, float]]:
        """
        Returns:
            A nested dict `{ <user_id>: { <capability_id>: <user_ability> } }`
        """
        user_cap_dict: dict[str, dict[str, float]] = {}
        for user_id, cap_id, user_ability in self.user_capability_iter():
            user_cap_dict.setdefault(user_id, {})
            user_cap_dict[user_id][cap_id] = user_ability
        return user_cap_dict

    def item_difficulty_dict(self) -> dict[str, float]:
        return {idx: diff for idx, diff in self.item_difficulty_iter()}

    def user_task_to_csv(self, path: str | bytes | os.PathLike):
        with open(path, "w", newline="") as f:
            csv_writer = csv.writer(f)
            csv_writer.writerow(["userid", "taskid", "ability"])
            for userid, taskid, ability in self.user_task_iter():
                csv_writer.writerow([userid, taskid, ability])

    def user_capability_to_csv(self, path: str | bytes | os.PathLike):
        with open(path, "w", newline="") as f:
            csv_writer = csv.writer(f)
            csv_writer.writerow(["userid", "capabilityid", "ability"])
            for userid, capid, ability in self.user_capability_iter():
                csv_writer.writerow([userid, capid, ability])

    def item_difficulty_to_csv(self, path: str | bytes | os.PathLike):
        with open(path, "w", newline="") as f:
            csv_writer = csv.writer(f)
            csv_writer.writerow(["itemid", "difficulty"])
            for itemid, diff in self.item_difficulty_iter():
                csv_writer.writerow([itemid, diff])


class IRTTrainer:
    def __init__(self, cfg: TrainerConfig, device: str):
        self.cfg = cfg
        self.device = device

        self.n_epochs = self.cfg.n_epochs
        self.lr = self.cfg.lr
        self.batch_size = self.cfg.batch_size
        self.val_freq = self.cfg.val_freq
        self.val_ratio = self.cfg.val_ratio
        self.val_seed = 0

    def fit(
        self, data: IRTDataset, net: HierarchicalItemResponseTheoryNet
    ) -> tuple[IRTTrainResult, Optional[dict[str, float]]]:
        best_model_state: Optional[tuple[dict, dict]] = None
        best_val_metrics: Optional[dict[str, float]] = None

        if self.val_ratio > 0:
            train_data, val_data = data.split_by_log(heldout_ratio=self.val_ratio, random_seed=self.val_seed)
            evaluator = Evaluator(EvaluatorConfig(), device=self.device)
        else:
            train_data, val_data = data, None

        train_dataset: IRTLogDataset = IRTLogDataset(train_data)
        train_dataloader = DataLoader(
            train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
        )

        # set up optimizer and trainer
        user_params: dict[str, nn.Parameter] = {
            k: nn.Parameter(
                torch.zeros(train_dataset.num_users, *p.detach().shape).to(self.device),
                requires_grad=True,
            )
            for k, p in net.get_user_params().items()
        }
        net.init_user_params(user_params)
        optimizer = optim.Adam(
            list(user_params.values()) + list(net.get_item_params().values()),
            lr=self.lr,
        )

        def get_current_state() -> tuple[dict, dict]:
            current_user_params = {k: v.clone() for k, v in user_params.items()}
            current_item_params = {k: v.clone() for k, v in net.get_item_params().items()}
            return current_user_params, current_item_params

        # training and validation
        net.train()
        for ep in range(1, self.n_epochs + 1):
            logger.info(f"Training epoch {ep}")

            # train and record
            ep_losses, ep_preds, ep_labels = [], [], []  # for train record
            for batch in tqdm(train_dataloader):
                (
                    loss,
                    preds,
                    labels,
                ) = self._train_batch(net, user_params, batch)
                ep_losses.append(loss.item())
                ep_preds.extend(preds)
                ep_labels.extend(labels)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            # track training with logger and writer
            ep_loss = sum(ep_losses) / len(ep_losses)
            ep_preds_np, ep_labels_np = (
                np.array(ep_preds),
                np.array(ep_labels, dtype=int),
            )
            bin_preds_np = np.where(ep_preds_np > 0.5, 1, 0)
            ep_acc = accuracy_score(ep_labels_np, bin_preds_np)
            ep_auc = roc_auc_score(ep_labels_np, ep_preds_np)
            logger.info(f"[train] Epoch {ep}: acc={ep_acc:.4f}, auc={ep_auc:.4f}, loss={ep_loss:.4f}")

            # validation per `val_freq` epochs
            if (val_data is not None) and (ep % self.val_freq == 0):
                logger.info(f"Validation epoch {ep}")
                val_metrics, _ = evaluator.evaluate(val_data, net, user_params)
                logger.info(
                    f'[val]Epoch {ep}: acc={val_metrics["acc"]:.4f}, '
                    f'auc={val_metrics["auc"]:.4f}, '
                    f'loss={val_metrics["loss"]:.4f}'
                )
                # update and optionally save best model
                if (best_val_metrics is None) or all(
                    val_metrics[k] >= best_val_metrics.get(k, 0) for k in ("acc", "auc")
                ):
                    best_model_state = get_current_state()
                    best_val_metrics = val_metrics

        result = (
            IRTTrainResult(data, *best_model_state)
            if best_model_state is not None
            else IRTTrainResult(data, user_params, net.get_item_params())
        )

        return result, best_val_metrics

    def _train_batch(
        self,
        model: ItemResponseTheoryNet | HierarchicalItemResponseTheoryNet,
        user_params: dict[str, nn.Parameter],
        batch: tuple[torch.Tensor, torch.Tensor, torch.Tensor],
    ):
        user_nos, item_nos, labels = batch
        user_nos = user_nos.long().to(self.device)
        item_nos = item_nos.long().to(self.device)
        labels = labels.float().to(self.device)

        preds = functional_call(
            model,
            {k: p[user_nos] for k, p in user_params.items()},
            args=(item_nos,),
        )
        loss = nn.BCELoss()(preds, labels)
        preds_list = preds.detach().cpu().numpy().tolist()
        labels_list = labels.detach().cpu().numpy().tolist()
        return loss, preds_list, labels_list
