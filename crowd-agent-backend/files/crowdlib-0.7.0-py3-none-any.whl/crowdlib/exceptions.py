class CrowdLibException(Exception):
    """Crowdlib base exception"""

    pass


class TrinoQueryError(CrowdLibException):
    """Trino query error"""

    pass


class DanluServiceOpsError(CrowdLibException):
    """Danlu service ops error"""

    pass
