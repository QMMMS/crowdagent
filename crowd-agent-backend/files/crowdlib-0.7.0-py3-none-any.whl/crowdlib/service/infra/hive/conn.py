from __future__ import annotations

import threading
import warnings
from typing import Any, List, Optional

import httpx
from trino.auth import BasicAuthentication
from trino.dbapi import connect

from crowdlib.exceptions import TrinoQueryError

warnings.filterwarnings("ignore")


class OlapConn:
    def __init__(
        self,
        username: str,
        secret_key: str,
        trino_url: str,
        catalog: str = "hive",
        query_properties: Optional[dict] = None,
    ):
        self.trino_url = trino_url
        self.username = username
        self.secret_key = secret_key
        self.catalog = catalog
        self.conn = connect(
            host=trino_url,
            auth=BasicAuthentication(username=self.username, password=self.secret_key),
            http_scheme="https",
            user=username,
            catalog=catalog,
            session_properties=query_properties,
            verify=False,
        )
        self.client = httpx.Client(
            headers={
                "X-Trino-User": username,
                "X-Trino-Source": "pyshuyuan",
                "X-Trino-Catalog": catalog,
            },
            verify=False,
            auth=(username, secret_key),
        )

    def execute_query(self, sql: str):
        cursor = OlapCursor(self)
        cursor.execute(sql)
        return cursor

    def execute_query_background(self, sql: str):
        cursor = OlapCursor(self)
        thread = threading.Thread(target=cursor.execute, args=(sql,))
        thread.start()
        return cursor

    def close(self):
        self.conn.close()
        self.client.close()


class OlapCursor:
    def __init__(self, olap_conn: OlapConn):
        self._olap_conn = olap_conn
        self._cursor = olap_conn.conn.cursor()

    def fetchall(self) -> List[List[Any]]:
        try:
            return self._cursor.fetchall()
        except Exception as e:
            raise TrinoQueryError(str(e))

    def fetchone(self) -> Optional[List[Any]]:
        try:
            return self._cursor.fetchone()
        except Exception as e:
            raise TrinoQueryError(str(e))

    def fetchmany(self, size=None) -> List[List[Any]]:
        try:
            return self._cursor.fetchmany(size)
        except Exception as e:
            raise TrinoQueryError(str(e))

    def execute(self, operation, parameters=None, **kwargs):
        try:
            self._cursor = self._cursor.execute(operation, parameters, **kwargs)
        except Exception as e:
            raise TrinoQueryError(str(e))
        return self

    def get_state(self):
        if self._cursor.query_id is None or self._cursor.__iter__() is None:
            return "NOT READY"
        r = self._olap_conn.client.get(url=f"{self._olap_conn.trino_url}/v1/query/{self._cursor.query_id}")
        if r.status_code == 200:
            return r.json()["state"]
        elif r.status_code == 401:
            raise TrinoQueryError("Unauthorized")
        else:
            raise TrinoQueryError(f"Unknown error: {r.status_code!r} {r.read()!r}")

    def cancel_query(self):
        r = self._olap_conn.client.put(url=f"{self._olap_conn.trino_url}/v1/query/{self._cursor.query_id}/killed")
        if r.status_code != 202:
            raise TrinoQueryError(f"Cancel failed: {r.status_code!r} {r.read()!r}")

    def close(self):
        self._cursor.close()
