from __future__ import annotations

import json
import logging
import time
from collections import namedtuple
from typing import Optional

from requests import Response

from crowdlib.service.infra.danlu._openapi import OpenApiRequest
from crowdlib.service.infra.danlu.base import DanluOpsBase, ServiceOpsResult
from crowdlib.service.infra.danlu.util import handle_http_response

logger = logging.getLogger(__name__)


class DanluServiceOps(DanluOpsBase):
    """
    丹炉服务: 查询服务状态、暂停服务、更新服务
    """

    def __init__(self, access_key: str, access_secret: str, app_id: int) -> None:
        super().__init__(access_key=access_key, access_secret=access_secret)
        self.app_id = app_id

    def get_service_status(self) -> str:
        """
        查询服务状态
        """
        ops_result = self.get_service_info()
        return self._parse_service_status(ops_result.data)

    def get_service_info(self) -> ServiceOpsResult:
        """
        查询服务全部信息
        """
        resp = self._get_service_info()
        return ServiceOpsResult(status_code=resp.status_code, data=resp.json())

    def pause_service(self) -> ServiceOpsResult:
        """
        暂停服务
        """
        resp = self._pause_service()
        return ServiceOpsResult(status_code=resp.status_code, data=resp.json())

    def update_service(self, request_body: Optional[dict] = None) -> ServiceOpsResult:
        """
        更新服务
        """
        resp = self._update_service(request_body=request_body)
        return ServiceOpsResult(status_code=resp.status_code, data=resp.json())

    @handle_http_response(expected_status_codes=[200])
    def _get_service_info(self) -> Response:
        openapi_request = OpenApiRequest(
            self.signer,
            method="GET",
            url=f"{self.api_host}/api/v1/apps/{self.app_id}",
            headers={"Content-Type": "application/json"},
        )
        response = openapi_request.request()
        return response

    @handle_http_response(expected_status_codes=[201, 202])
    def _pause_service(self) -> Response:
        openapi_request = OpenApiRequest(
            self.signer,
            method="POST",
            url=f"{self.api_host}/api/v1/apps/{self.app_id}/stop",
            headers={"Content-Type": "application/json"},
        )
        response = openapi_request.request()
        return response

    @handle_http_response(expected_status_codes=[201, 202])
    def _update_service(self, request_body: Optional[dict] = None) -> Response:
        openapi_request = OpenApiRequest(
            self.signer,
            method="POST",
            url=f"{self.api_host}/api/v1/apps/{self.app_id}",
            headers={"Content-Type": "application/json"},
            body=json.dumps(request_body).encode("utf-8"),
        )
        response = openapi_request.request()
        return response

    @staticmethod
    def _parse_image_name_from_service_info(service_info: dict) -> str:
        return service_info["containerInfo"][0]["imageName"]

    @staticmethod
    def _parse_service_status(service_info: dict) -> str:
        return service_info.get("status", "null")


UpdateStatus = namedtuple("UpdateStatus", ["success", "message"])


class DanluServiceOpsImageUpdate(DanluServiceOps):
    def __init__(
        self,
        access_key: str,
        access_secret: str,
        app_id: int,
        image_tag: str,
        image_name: Optional[str] = None,
    ) -> None:
        """
        根据新的镜像tag更新服务，持续检查服务状态，直到服务状态为running或error

        Args:
            access_key: Access key
            access_secret: Access secret
            app_id: Application service id
            image_tag: New image tag, e.g. `0.1.0` for example
            image_name: New image name, e.g. `fuxi-robot-crowdsourcing/crowdsourcing-algo/crowdlib-doc` for example. The default is `None`, will use the current in-used image name of the service.
        """
        super().__init__(access_key=access_key, access_secret=access_secret, app_id=app_id)
        self.image_tag = image_tag
        self.image_name = image_name

    def get_service_image_name(self) -> str:
        """
        获取服务当前使用的镜像名称
        """
        get_info_ops_result = self.get_service_info()
        return self._parse_image_name_from_service_info(get_info_ops_result.data)

    def update_service_image(self) -> Optional[ServiceOpsResult]:
        """
        更新服务镜像(仅触发)
        """
        get_info_ops_result = self.get_service_info()
        info = get_info_ops_result.data

        # check service status: make sure it's running before update
        status = self._parse_service_status(info)
        if status not in ["running", "error"]:
            logger.warning(f"model service {self.app_id} status: {status}, not running, skip update")
            return None

        request_body = {}
        columns = ["containerInfo", "podConfigs"]
        for column in columns:
            request_body[column] = info[column]
        # 配置Image Version
        if self.image_name is not None:
            new_image_name = f"{self.image_name}:{self.image_tag}"
        else:
            current_image = self._parse_image_name_from_service_info(info)
            new_image_name = f"{current_image.split(':')[0]}:{self.image_tag}"
        request_body["containerInfo"][0]["imageName"] = new_image_name
        update_ops_result = self.update_service(request_body=request_body)
        return update_ops_result

    def update_service_image_with_check(
        self,
        timeout: int = 600,
        check_interval: int = 60,
    ) -> UpdateStatus:
        """
        更新服务镜像并持续检查服务状态，直到服务状态为running或error

        Args:
            timeout: 超时时间，单位秒
            check_interval: 检查间隔，单位秒
        """
        start_time = time.time()

        update_ops_result = self.update_service_image()
        if update_ops_result is None:
            return UpdateStatus(success=False, message="service not running, skip update")

        update_resp_info = update_ops_result.data
        logger.info(
            f"[Update]model service {self.app_id}: "
            f"cluster name: {update_resp_info['clusterName']},"
            f"service name: {update_resp_info['name']}"
        )

        while time.time() - start_time < timeout:
            time.sleep(check_interval)
            get_info_ops_result = self.get_service_info()
            info = get_info_ops_result.data
            status = self._parse_service_status(info)
            logger.info(f"[After Run Update]model service {self.app_id} status: {status}")
            if status == "running":
                image_name = self._parse_image_name_from_service_info(info)
                logger.info(
                    f"[After Run Update]update model service {self.app_id} success, image in used: {image_name}"
                )
                return UpdateStatus(success=True, message="update success")
            elif status == "error":
                logger.error(f"[After Run Update]update model service {self.app_id} got error")
                return UpdateStatus(success=False, message="update failed, service status error")
        return UpdateStatus(success=False, message="update timeout")


if __name__ == "__main__":
    import logging

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler()],
    )

    ACCESS_KEY = "xxx"
    ACCESS_SECRET = "xxx"

    update_image = DanluServiceOpsImageUpdate(
        access_key=ACCESS_KEY,
        access_secret=ACCESS_SECRET,
        app_id=85123,
        image_tag="0.1.0-rc2",
    )
    update_image.update_service_image_with_check(timeout=600, check_interval=10)
