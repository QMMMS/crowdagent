from __future__ import annotations

import abc
import logging
from typing import Union

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class AgreementBase:
    """
    Agreement 计算。
    """

    def __init__(self, label_set: Union[list, tuple]):
        self._label_set = label_set

    @property
    def label_set(self) -> tuple:
        """
        保证label_set不变。

        Returns:
            unchangeable label set(tuple type)
        """
        if isinstance(self._label_set, list):
            return tuple(self._label_set)
        return self._label_set

    @abc.abstractmethod
    def cal_agreement(self, df_table: pd.DataFrame) -> float:
        """Calculate agreement within a pd.Dataframe.

        Args:
            df_table: dataset with columns [`qid`, `uid`, `label`], the `uid` column is optional.

        Returns:
            agreement: The agreement value.
        """
        raise NotImplementedError

    def cal_agreement_contribution(
        self,
        df_table: pd.DataFrame,
        target_uid: int,
    ) -> tuple[float, float]:
        """Calculate agreement with or without the target user.

        Args:
            df_table: annotation table, with columns [`qid`, `uid`, `label`]
            target_uid: the target user id.

        Returns:
            agreements: (agreement with target user, agreement without target user)
        """
        self._validate_agreement_contribution_input_dataframe(df_table, target_uid)

        df_with_tuid = df_table
        df_without_tuid = df_table.drop(df_table[df_table["uid"] == target_uid].index).reset_index(drop=True)

        agreement_with_tuid = self.cal_agreement(df_with_tuid)
        agreement_without_tuid = self.cal_agreement(df_without_tuid)

        return agreement_with_tuid, agreement_without_tuid

    def _validate_agreement_input_dataframe(self, df_table: pd.DataFrame) -> None:
        """验证输入DataFrame的格式"""
        if not isinstance(df_table, pd.DataFrame) or not {"qid", "label"}.issubset(df_table.columns):
            raise ValueError("Input must be a DataFrame with 'qid' and 'label' columns")
        if df_table.empty:
            raise ValueError("Input with empty data")
        # all label should in label_set
        labels = [label for label in np.hstack(df_table["label"].values) if label is not None]
        if not set(labels).issubset(set(self.label_set)):
            raise ValueError("Labels not in label_set")

        # 确保每个问题的参与人数>=2，避免计算trivial agreement(单人标注的agreement)
        qid_group = df_table.groupby("qid")
        for qid, group in qid_group:
            if len(group["uid"].unique()) < 2:
                raise ValueError(
                    f"Rater number must >= 2 for every question, " f"which is not satisfied in question: {qid}"
                )

    @staticmethod
    def _validate_agreement_contribution_input_dataframe(df_table: pd.DataFrame, target_uid: int) -> None:
        """验证输入DataFrame的格式"""
        if not isinstance(df_table, pd.DataFrame) or not {"qid", "label", "uid"}.issubset(df_table.columns):
            raise ValueError("Input must be a DataFrame with 'qid', 'uid' and 'label' columns")

        if target_uid not in df_table["uid"].values:
            raise ValueError(f"Can not find user with {target_uid=}")

        # 确保每个问题的参与人数>=3，否则计算出的contribution无实际意义
        qid_group = df_table.groupby("qid")
        for qid, group in qid_group:
            if len(group["uid"].unique()) < 3:
                raise ValueError(
                    f"Rater number must >= 3 for every question, " f"which is not satisfied in question: {qid}"
                )
