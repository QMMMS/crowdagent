from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from crowdlib.learn.irt.dataset import IRTDataset
from crowdlib.learn.irt.dataset.knowledge import KnowledgeHierarchy


def batched_index_select(input: torch.Tensor, dim: int, index: torch.Tensor) -> torch.Tensor:
    """Implement `torch.index_select()` for batched tensor

    see https://discuss.pytorch.org/t/batched-index-select/9115/9
    """
    for ii in range(1, len(input.shape)):
        if ii != dim:
            index = index.unsqueeze(ii)
    expanse = list(input.shape)
    expanse[0] = -1
    expanse[dim] = -1
    index = index.expand(expanse)
    return torch.gather(input, dim, index)


class ItemResponseTheoryNet(nn.Module):
    r"""Implementation of ordinary Item Response Theory model.

    Each user has one real-valued ability parameter;
    Each item has one real-valued difficulty parameter.
    """

    def __init__(self, cfg: dict):
        nn.Module.__init__(self)
        self.cfg = cfg
        # set up vanilla params
        data: IRTDataset = cfg["data"]
        stats = data.statistics()
        self.user_params = nn.Parameter(torch.tensor([0.0]), requires_grad=True)
        self.item_params = nn.Embedding(stats.n_items, 1)
        self.device = self.cfg["device"]

    def forward(self, item_nos: torch.LongTensor) -> torch.Tensor:
        # for user_params.ndim == 1, last dims are the parameter
        user_params = self.user_params
        item_params = self.item_params(item_nos)
        assert user_params.size(-1) == 1
        assert item_params.size(-1) == 1
        assert (
            item_params.ndim == user_params.ndim
        ), f"item params shape {item_params.size()} != user params shape {user_params.size()}"

        result = torch.sigmoid(user_params - item_params).squeeze(-1)
        return result

    def init_user_params(self, param_dict: dict) -> None:
        for k, p in param_dict.items():
            nn.init.xavier_normal_(p)

    def get_user_params(self) -> dict[str, nn.Parameter]:
        return {k: v for k, v in self.named_parameters() if k.startswith("user_params")}

    def get_item_params(self) -> dict[str, nn.Parameter]:
        item_param_dict = {k: v for k, v in self.named_parameters() if k.startswith("item_params")}
        return item_param_dict


class HierarchicalItemResponseTheoryNet(nn.Module):
    r"""Implementation of Hierarchical Item Response Theory model.

    Each user has one real-valued ability parameter **at each node in the hierarchy** (different from `ItemResponseTheoryNet`);
    Each item has one real-valued difficulty parameter.

    Note:
        The user parameters in this model actually represent the **bias** from the parent node,
        i.e., to obtain the "absolute" ability value at one node, you should sum the parameters along the whole path from root to the node.
    """

    def __init__(self, cfg: dict):
        nn.Module.__init__(self)
        self.cfg = cfg
        self.data: IRTDataset = cfg["data"]
        self.device = self.cfg["device"]
        stats = self.data.statistics()

        # construct user parameters with knowledge hierarchy
        self.hierarchy = KnowledgeHierarchy(self.data)
        self.height = self.hierarchy.get_depth()
        self.node_num = self.hierarchy.get_node_num()

        # set up vanilla params
        self.user_params = nn.Parameter(torch.zeros((self.node_num, 1)).to(self.device))
        self.item_params = nn.Embedding(stats.n_items, 1)

        self.item_leaves_matrix = self.hierarchy.get_item_leaves_matrix()
        self.node_path_matrix = self.hierarchy.get_node_path_matrix()

    def forward(self, item_nos: torch.Tensor) -> torch.Tensor:
        # self.user_params: (B, N, 1)
        item_nos = item_nos.unsqueeze(-1)  # (B, 1)
        item_nos_np: np.ndarray = item_nos.cpu().numpy()  # (B, 1)
        leaf_nodes = self.item_leaves_matrix[item_nos_np, 0]  # (B, 1)
        path_np = self.node_path_matrix[leaf_nodes, :]  # (B, 1, D)
        path = torch.from_numpy(path_np).long().to(self.device)  # (B, 1, D)
        user_params = torch.tensor(0.0).to(self.device)
        D = path_np.shape[-1]
        for d in range(D):
            hier_params = batched_index_select(self.user_params, 1, path[:, :, d])  # (B, 1, 1)
            user_params = user_params + hier_params

        item_params = self.item_params(item_nos)

        assert user_params.size(-1) == 1  # original irt trait
        assert item_params.size(-1) == 1  # original irt trait
        assert (
            item_params.ndim == user_params.ndim
        ), f"item params shape {item_params.size()} != user params shape {user_params.size()}"

        result = torch.sigmoid(user_params - item_params).squeeze(dim=(-1, -2))
        return result

    def init_user_params(self, param_dict: dict) -> None:
        for k, p in param_dict.items():
            nn.init.xavier_normal_(p)

    def get_user_params(self) -> dict[str, nn.Parameter]:
        return {k: v for k, v in self.named_parameters() if k.startswith("user_params")}

    def get_item_params(self) -> dict[str, nn.Parameter]:
        return {k: v for k, v in self.named_parameters() if k.startswith("item_params")}
