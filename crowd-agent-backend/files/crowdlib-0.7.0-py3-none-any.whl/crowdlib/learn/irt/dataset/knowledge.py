from __future__ import annotations

from dataclasses import dataclass, field
from queue import Queue
from typing import Optional

import numpy as np

from .base import IRTDataset


@dataclass(frozen=False)
class KnowledgeHierarchyNode:
    knowledge_id: str = field(default_factory=str)
    global_index: int = field(default_factory=int)
    level: int = field(default_factory=int)
    local_index: int = field(default_factory=int)
    children: list["KnowledgeHierarchyNode"] = field(default_factory=list)
    parent: Optional["KnowledgeHierarchyNode"] = field(default=None)
    related_items: list[int] = field(default_factory=list)


class KnowledgeHierarchy:
    """The data structure to represent a knowledge hierarchy/tree.
    A hierarchy is constrcuted from a Dataset object where predecessors/successors information is stored.
    The constructor will automatically detect where the information of the dataset obeys a tree structure.
    The structure is immutable. Once constructed from a dataset, the hierarchy is assumed to be fixed.

    Node index
    For each node in the tree, there are two encoding systems:
    (1) global_index (gidx): a unique int in the tree;
    (2) positional_index (pidx): a unique int pair (level, local_index) in the tree.
    Levels start from 0. That means, the root node will always have pidx=(0, 0)
    """

    def __init__(self, data: IRTDataset):
        # construct the knowledge hierarchy from dataset
        k_ids = data.meta.knowledge_ids
        k_preds = data.knowledges.predecessors
        k_succs = data.knowledges.successors
        k_rel_items = data.knowledges.related_items

        # sanity check: whether the knowledge structure is a tree

        root_candidates = []
        for k_idx, preds in enumerate(k_preds):
            if len(preds) > 1:
                raise ValueError(f"Knowledge {k_idx} has multiple predecessors: {preds}")
            if len(preds) == 0:
                root_candidates.append(k_idx)
        if len(root_candidates) == 0:
            # cycle detection not complete
            raise ValueError("Cycle detected")

        # create nodes
        self.nodes = [
            KnowledgeHierarchyNode(knowledge_id=kid, global_index=i, children=[], parent=None)
            for i, kid in enumerate(k_ids)
        ]
        self.root = None
        # we use a trick where (kid == gidx)
        for i, node in enumerate(self.nodes):
            node.children = [self.nodes[i] for i in k_succs[i]]
            if k_preds[i]:
                node.parent = self.nodes[k_preds[i][0]]
            else:
                self.root = node
        # create a artificial root if we have multiple root candidates
        if len(root_candidates) > 1:
            new_root = KnowledgeHierarchyNode(
                knowledge_id="PSEUDO_ROOT",
                global_index=len(self.nodes),
                children=[self.nodes[i] for i in root_candidates],
                parent=None,
            )
            for i in root_candidates:
                self.nodes[i].parent = new_root
            self.nodes.append(new_root)
            self.root = new_root
        assert self.root is not None, "No root node specified!"
        self.node_num = len(self.nodes)

        self.knowledge_id2idx = {id_: idx for idx, id_ in enumerate(k_ids)}

        # store structure info into nodes
        self.structure_map: dict[int, dict[int, int]] = {}  # level -> local_index -> global_idx
        self.structure_inverse_map: dict[int, tuple[int, int]] = {}  # global_idx -> (level, local_index)
        queue: Queue = Queue()
        queue.put((0, self.root.global_index))  # root
        while not queue.empty():
            level, global_index = queue.get()
            node = self.nodes[global_index]
            node.level = level
            self.structure_map.setdefault(level, {})
            node.local_index = len(self.structure_map[level])
            self.structure_map[level][node.local_index] = global_index
            self.structure_inverse_map[global_index] = (level, node.local_index)
            for i, child in enumerate(node.children):
                queue.put((level + 1, child.global_index))

        self.depth = len(self.structure_map)

        ############# end of hierarchy construction #############
        ############# start of information register #############

        # store path information for each node
        self.node_path: dict[int, list[int]] = {}
        for gidx, node in enumerate(self.nodes):
            path: list[int] = [gidx]
            i = gidx
            while True:
                p = self.nodes[i].parent
                if p is None:
                    break
                path.append(p.global_index)
                i = p.global_index
            self.node_path[gidx] = list(reversed(path))
        # check if all nodes has path
        assert (
            len(self.node_path) == self.node_num
        ), f"Some nodes have no path in the knowledge hierarchy: {set(range(len(self.nodes))) - set(self.node_path.keys())}"
        # cache the information as numpy array
        self.node_path_matrix = np.full((self.node_num, self.depth), -1, dtype=np.int64)
        for i in range(self.node_num):
            path = self.node_path[i]
            self.node_path_matrix[i, : len(path)] = np.array(path)

        # store related items into leaves, and store the gidx of leaves for each item
        n_items = len(data.meta.item_ids)
        self.item_leaves: dict[int, list[int]] = {}
        for k_idx, item_indices in enumerate(k_rel_items):
            node = self.nodes[k_idx]
            # only process leaf nodes
            if len(node.children) > 0:
                continue
            node.related_items = item_indices[:]
            for item_idx in node.related_items:
                self.item_leaves.setdefault(item_idx, [])
                self.item_leaves[item_idx].append(node.global_index)
        # check if all items has leaves
        assert (
            len(self.item_leaves) == n_items
        ), f"Some items have no related leaf in the knowledge hierarchy: {set(range(len(data.meta.item_ids))) - set(self.item_leaves.keys())}"
        # cache the information as numpy array
        max_num_leaves = max(map(len, self.item_leaves.values()))
        self.item_leaves_matrix = np.full((n_items, max_num_leaves), -1, dtype=np.int64)
        for i in range(n_items):
            leaves = self.item_leaves[i]
            self.item_leaves_matrix[i, : len(leaves)] = np.array(leaves)

    def get_root(self) -> Optional[KnowledgeHierarchyNode]:
        return self.root

    def get_nodes(self) -> list[KnowledgeHierarchyNode]:
        return self.nodes

    def get_level_width(self, level: int) -> int:
        return len(self.structure_map[level])

    def get_level_nodes(self, level) -> list[KnowledgeHierarchyNode]:
        return [self.nodes[i] for i in self.structure_map[level].values()]

    def get_node_num(self) -> int:
        return self.node_num

    def get_depth(self) -> int:
        return self.depth

    def get_node_by_id(self, knowledge_id: str) -> KnowledgeHierarchyNode:
        return self.get_node_by_index(self.knowledge_id2idx[knowledge_id])

    def get_node_by_index(self, global_index: int) -> KnowledgeHierarchyNode:
        return self.nodes[global_index]

    def get_node_by_pos(self, level: int, local_index: int) -> KnowledgeHierarchyNode:
        return self.nodes[self.structure_map[level][local_index]]

    def get_pos_by_id(self, knowledge_id: str) -> tuple[int, int]:
        return self.get_pos_by_index(self.knowledge_id2idx[knowledge_id])

    def get_pos_by_index(self, global_index: int) -> tuple[int, int]:
        return self.structure_inverse_map[global_index]

    def get_node_path_by_index(self, global_index: int) -> list[int]:
        return self.node_path[global_index]

    def get_node_path_matrix(self) -> np.ndarray:
        return self.node_path_matrix.copy()

    def get_item_leaves_by_index(self, item_index: int) -> list[int]:
        return self.item_leaves[item_index]

    def get_item_leaves_matrix(self) -> np.ndarray:
        return self.item_leaves_matrix.copy()
