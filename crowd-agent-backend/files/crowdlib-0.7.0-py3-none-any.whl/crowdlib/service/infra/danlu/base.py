from __future__ import annotations

from collections import namedtuple

from crowdlib.service.infra.danlu._openapi import Signer


class DanluOpsBase:
    """
    丹炉 OpenAPI 操作: 自动签名、请求

    Note:
        1. 丹炉 OpenAPI API Host: [`http://api.danlu.netease.com:36005`](https://confluence.leihuo.netease.com/pages/viewpage.action?pageId=77584850)
        2. 丹炉 OpenAPI `access_key` 和 `access_secret` 获取: [OpenAPI账号列表](https://danlu.netease.com/workbench/#/workbench/project/detail/2170?project_id=2170)
    """

    def __init__(self, access_key: str, access_secret: str) -> None:
        self.api_host = "http://api.danlu.netease.com:36005"
        self.signer = self.get_signer(access_key, access_secret)

    @staticmethod
    def get_signer(access_key: str, access_secret: str) -> Signer:
        signer = Signer(access_key, access_secret)
        return signer


ServiceOpsResult = namedtuple("ServiceOpsResult", ["status_code", "data"])
