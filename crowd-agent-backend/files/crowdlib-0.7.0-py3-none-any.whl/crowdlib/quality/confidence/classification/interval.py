from __future__ import annotations

from dataclasses import dataclass

from scipy.stats import binomtest


@dataclass
class TendencyChoiceEstimator:
    """
    基于选择题当前的选项倾向情况，预估相关的指标：如收敛置信度，最小继续标注人数等

    Tendency是题目(选择题)当前占比最大的选项, 通过评估其相关指标来得到当前题目的标注状态。

    在单选题中，tendency就是当前被选择多的选项，其被选择的次数就是`positive_count`，没有选中此选项的计入`negative_count`，
    如3选1题目，10人答题，A，B，C三个选项的计数分别是6，3，1，那么这里的tendency就是A，`positive_count`就是6，`negative_count`为4(10-6=4)。

    多选题类似，tendency也是当前累积被选择最多的选项，如3个候选项的选择题，10人答题，A，B，C被选中的次数累积为6, 8, 1,
    那么这里的tendency就是B，`positive_count`就是8，`negative_count`为2(10-8=2)。

    估计收敛置信度:

    Examples:
        >>> from crowdlib.quality.confidence.classification.interval import TendencyChoiceEstimator
        >>> estimator = TendencyChoiceEstimator(positive_count=10, negative_count=8)
        >>> estimator.estimate_converge_confidence()
        0.36

    估计最小继续标注人数:

    Examples:
        >>> from crowdlib.quality.confidence.classification.interval import TendencyChoiceEstimator
        >>> estimator = TendencyChoiceEstimator(positive_count=10, negative_count=8)
        >>> estimator.estimate_continue_worker_num(target_confidence=0.95)
        8
        >>> estimator.estimate_continue_worker_num(target_confidence=0.99)
        13
    """

    positive_count: int
    """Tendency选项被选择的次数"""
    negative_count: int
    """Tendency选项未被选择的次数"""

    def __post_init__(self):
        if self.positive_count < 0 or self.negative_count < 0:
            raise ValueError(f"The count value should >= 0, " f"not get {self.positive_count=}, {self.negative_count=}")

    def estimate_converge_confidence(self, confidence_upper_bound: float = 1.0):
        """
        评估当前tendency的收敛的置信度: 通过二分法找到使得置信区间收敛到1(下界>0.5)的置信度。

        收敛置信度：我们有多大的把握说当前题目会最终收敛到tendency。

        Args:
            confidence_upper_bound: 置信度上界

        Returns:
            预估收敛置信度
        """
        # Initial lower and upper bounds for the confidence level
        lower_bound = 0.01
        upper_bound = confidence_upper_bound
        converge_confidence = 0.0
        # Binary search to find the required confidence level
        while lower_bound <= upper_bound:
            iter_confidence = round((lower_bound + upper_bound) / 2, 2)
            iter_interval = wilson_interval(self.positive_count, self.negative_count, confidence=iter_confidence)

            if not iter_interval.is_converged_to_1():
                upper_bound = iter_confidence - 0.01
            else:
                lower_bound = iter_confidence + 0.01
                converge_confidence = iter_confidence

        return converge_confidence

    def estimate_continue_worker_num(self, target_confidence: float) -> int:
        """计算需要的继续标注最小人数。

        最小标注人数是最快达到收敛状态需要的人数。
        要想基于当前的状态最快地达到收敛状态，理想的情况就是后续的标注员持续选择tendency选项直至收敛状态(达到预设的置信度)。
        这里通过二分搜索来找到达到预设置信度(`target_confidence`)需要的最小标注人数。

        Args:
            target_confidence: 要求达到的置信度

        Returns:
            add_cnt: 需要的继续标注最小人数
        """
        max_add_cnt = 10000
        min_add_cnt = 0
        add_cnt = 0
        while min_add_cnt <= max_add_cnt:
            cnt = int((min_add_cnt + max_add_cnt) / 2)

            if self.positive_count + cnt <= self.negative_count:
                min_add_cnt = cnt + 1
                continue

            iter_interval = wilson_interval(
                positive_count=self.positive_count + cnt,
                negative_count=self.negative_count,
                confidence=target_confidence,
            )
            if iter_interval.is_converged_to_1():
                add_cnt = cnt
                max_add_cnt = cnt - 1
            else:
                min_add_cnt = cnt + 1
        return add_cnt


@dataclass
class ConfidenceInterval:
    """
    置信区间。

    Examples:
        >>> from crowdlib.quality.confidence.classification.interval import ConfidenceInterval
        >>> ci = ConfidenceInterval(low=0.6, high=0.8)
        >>> ci.is_converged()
        True
        >>> ci.is_converged_to_1()
        True
    """

    low: float
    """置信度下界"""
    high: float
    """置信度上界"""

    def is_converged(self) -> bool:
        """
        当置信区间置于[0, 0.5)或(0.5, 1]时，认为当前区间处于**收敛**的状态
        """
        if self.low < 0.5 or self.high > 0.5:
            return True
        else:
            return False

    def is_converged_to_1(self) -> bool:
        """
        当置信区间置于(0.5, 1]时，认为当前区间处于**收敛至1**的状态
        """
        if self.low > 0.5:
            return True
        else:
            return False


def wilson_interval(
    positive_count: int,
    negative_count: int,
    confidence: float,
) -> ConfidenceInterval:
    """
    Wilson区间估计。

    Examples:
        >>> from crowdlib.quality.confidence.classification.interval import wilson_interval
        >>> ci = wilson_interval(positive_count=10, negative_count=5, confidence=0.95)
        >>> ci.low
        0.41713547738519774
        >>> ci.high
        0.8482367556028528

    Args:
        positive_count: 选中的次数(成功的次数)
        negative_count: 未被选中的次数(失败的次数)
        confidence: 置信度

    Returns:
        置信区间(置信度为confidence)
    """

    result = binomtest(k=positive_count, n=positive_count + negative_count)
    ci = result.proportion_ci(method="wilson", confidence_level=confidence)
    return ConfidenceInterval(low=float(ci.low), high=float(ci.high))


if __name__ == "__main__":
    import doctest

    doctest.testmod()
