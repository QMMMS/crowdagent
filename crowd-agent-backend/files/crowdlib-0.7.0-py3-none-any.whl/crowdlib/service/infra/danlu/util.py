from __future__ import annotations

import logging
from typing import List

from crowdlib.exceptions import DanluServiceOpsError

logger = logging.getLogger(__name__)


def handle_http_response(expected_status_codes: List[int]):
    def decorator(func):
        def wrapper(*args, **kwargs):
            response = func(*args, **kwargs)
            if response.status_code not in expected_status_codes:
                error_msg = f"Error[ {func.__name__}, {response.status_code}]: {response.content.decode()}"
                logger.error(error_msg)
                raise DanluServiceOpsError(error_msg)
            return response

        return wrapper

    return decorator
