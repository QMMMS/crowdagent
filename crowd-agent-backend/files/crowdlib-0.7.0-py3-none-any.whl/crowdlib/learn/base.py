from __future__ import annotations

import abc
import pathlib
from typing import Any

from pydantic import BaseModel, ConfigDict


class LearnConfig(BaseModel, abc.ABC):
    """Abstract class for learning model configuration."""

    model_config = ConfigDict(strict=True)


class LearnModel(abc.ABC):
    """Abstract class for learning models."""

    @abc.abstractmethod
    def train(self, data: Any, *args, **kwargs) -> Any:
        raise NotImplementedError

    @abc.abstractmethod
    def model_save(self, model_file_path: pathlib.Path):
        raise NotImplementedError

    @abc.abstractmethod
    def model_load(self, model_file_path: pathlib.Path) -> "LearnModel":
        raise NotImplementedError
