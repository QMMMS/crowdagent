from __future__ import annotations

import csv
import logging
import pathlib
from enum import Enum
from typing import List, Optional

from crowdlib.service.infra.hive.conn import OlapConn

logger = logging.getLogger(__name__)


class TrinoUrl(str, Enum):
    """
    The URL for Trino, which is used to query data from Hive.

    OUTER: The URL for querying data from Hive outside the intranet.
    INNER: The URL for querying data from Hive inside the intranet.
    """

    OUTER = "https://42.186.135.110:7990"
    INNER = "https://10.90.8.110:7990"


class HiveTrinoQueryClient:
    """
    通过Trino查询数源Hive数据，支持查询并保存到csv文件。

    Example:
        一次查询全部数据并保存到csv文件(数据量不大的情况):
        ```python
        username = "aop_zhongbao"
        secret_key = "xxx"
        columns = ["col1", "col2", "col3"]
        with HiveTrinoQueryClient(username, secret_key) as client:
            client.query_and_save(sql=f"select col1, col2, col3 from {some_db}.{some_table} where ds = '{some_ds}' limit 100",
                                  save_path="./tmp.csv",
                                  columns=columns)
        ```

        分批查询并保存到csv文件(数据量较大的情况):
        ```python
        username = "aop_zhongbao"
        secret_key = "xxx"
        columns = ["col1", "col2", "col3"]
        with HiveTrinoQueryClient(username, secret_key) as client:
            client.query_and_save(sql=f"select col1, col2, col3 from {some_db}.{some_table} where ds = '{some_ds}' limit 100",
                                  save_path="./tmp.csv",
                                  batch_size=10000,
                                  columns=columns)
        ```


    当前实现同样兼容 pyshuyuan [文档](https://shuyuan-sdk-docs.apps-sl.danlu.netease.com/#/python/bigdata/olap)中的用法。

    Note:
        最简单的替代方法是将原来`conn`的获取改为下面的方式即可, 之后的操作完全一致:
        ```python
        conn = HiveTrinoQueryClient(username="xxx", secret_key="xxx").conn
        ```
        但是这样需要手动关闭连接，所以推荐采用下面的方式:
        ```python
        with HiveTrinoQueryClient(username="xxx", secret_key="xxx") as client:
            conn = client.conn
            ...
        ```

    使用示例如下:

    Example:
        一次性获取所有数据，适用于结果集不大的情况:
        ```python
        with HiveTrinoQueryClient(username="xxx", secret_key="xxx") as client:
            conn = client.conn
            cursor = conn.execute_query(sql="select * from {some_db}.{some_table} where ds = '{some_ds}' limit 100")
            results = cursor.fetchall()
            cursor.close()
        ```

        每次获取单条数据:
        ```python
        with HiveTrinoQueryClient(username="xxx", secret_key="xxx") as client:
            conn = client.conn
            cursor = conn.execute_query(sql="select * from {some_db}.{some_table} where ds = '{some_ds}' limit 100")
            while True:
                result = cursor.fetchone()
                if result is None:
                    break
                print(result)
            cursor.close()
        ```
        每次获取多条数据:
        ```python
        with HiveTrinoQueryClient(username="xxx", secret_key="xxx") as client:
            conn = client.conn
            cursor = conn.execute_query(sql="select * from {some_db}.{some_table} where ds = '{some_ds}' limit 100")
            while True:
                # 每次获取多条数据
                result = cursor.fetchmany(10)
                if len(result) == 0:
                    break
                print(result)
            cursor.close()
        ```

    """

    def __init__(
        self,
        username: str,
        secret_key: str,
        trino_url: str = TrinoUrl.OUTER,
        catalog: str = "hive",
    ):
        self.username = username
        self.secret_key = secret_key
        self.trino_url = trino_url
        self.catalog = catalog

    def __enter__(self):
        self.conn = OlapConn(self.username, self.secret_key, self.trino_url, self.catalog)
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.conn.close()

    def query_and_save(
        self,
        sql: str,
        save_path: str | pathlib.Path,
        batch_size: Optional[int] = None,
        columns: Optional[List[str]] = None,
    ) -> None:
        """
        查询数据并保存到csv文件

        Args:
            sql: SQL查询语句
            save_path: csv文件保存路径
            batch_size: 每次查询的数据量, 用于分批查询。默认为None, 表示一次性查询全部数据；对于数据量较大的情况，建议设置为一个合适的值，如100000，1000000等
            columns: 列名, 用于csv文件的表头
        """
        cursor = self.conn.execute_query(sql=sql)
        with open(save_path, "w", newline="") as f:
            writer = csv.writer(f)
            # 写入列名(表头)
            if columns is not None and len(columns) > 0:
                writer.writerow(columns)

            if batch_size is None:  # 全部查询并保存
                results = cursor.fetchall()
                writer.writerows(results)
            else:  # 分批查询并保存
                while True:
                    result = cursor.fetchmany(batch_size)
                    if result is None or len(result) == 0:
                        break
                    writer.writerows(result)
        # 关闭cursor
        cursor.close()


if __name__ == "__main__":
    username = "aop_zhongbao"
    secret_key = "xxx"

    sql = (
        "select * from fuxi_robot_warehouse.dws_zhongbao_question_result_coarse_df "
        "where ds='2024-07-04' and userid=7477 limit 10"
    )
    with HiveTrinoQueryClient(username, secret_key) as client:
        client.query_and_save(sql, "tmp.csv", batch_size=1000)
