from __future__ import annotations

import copy
import itertools
import json
import random
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd


class IRTDataset(object):
    @dataclass
    class Logs:
        user_data: list[dict[int, int]] = field(default_factory=list)
        item_data: list[dict[int, int]] = field(default_factory=list)

    @dataclass
    class Knowledges:
        related_items: list[list[int]] = field(default_factory=list)
        predecessors: list[list[int]] = field(default_factory=list)
        successors: list[list[int]] = field(default_factory=list)

    @dataclass
    class Meta:
        user_ids: list[str] = field(default_factory=list)
        item_ids: list[str] = field(default_factory=list)
        knowledge_ids: list[str] = field(default_factory=list)

    @dataclass
    class Stats:
        n_logs: int
        n_users: int
        n_items: int
        n_knowledges: int
        n_logs_per_user_min: int
        n_logs_per_user_max: int
        n_logs_per_user_avg: float
        n_logs_per_item_min: int
        n_logs_per_item_max: int
        n_logs_per_item_avg: float
        n_logs_per_knowledge_min: int
        n_logs_per_knowledge_max: int
        n_logs_per_knowledge_avg: float
        label_distribution: float

    def __init__(self, logs: Logs, knowledges: Knowledges, meta: Meta):
        self.logs = logs
        self.knowledges = knowledges
        self.meta = meta

    @classmethod
    def from_tuples(cls, tuples: list[tuple[str, str, int]]) -> "IRTDataset":
        """build a IRT dataset with plain tuples

        Args:
            tuples: a list of tuples of (user_id, item_id, correct)
        """
        user_data_dict: dict = {}
        user_no2id: dict = {}
        user_id2no: dict = {}
        item_data_dict: dict = {}
        item_no2id: dict = {}
        item_id2no: dict = {}
        for user_id, item_id, correct in tuples:
            if user_id not in user_id2no:
                user_no = len(user_id2no)
                user_id2no[user_id] = user_no
                user_no2id[user_no] = user_id
            if item_id not in item_id2no:
                item_no = len(item_id2no)
                item_id2no[item_id] = item_no
                item_no2id[item_no] = item_id
            user_no, item_no = user_id2no[user_id], item_id2no[item_id]
            user_data_dict.setdefault(user_no, {})
            item_data_dict.setdefault(item_no, {})
            user_data_dict[user_no][item_no] = correct
            item_data_dict[item_no][user_no] = correct
        num_users, num_items = len(user_data_dict), len(item_data_dict)
        user_data = [user_data_dict[user_no] for user_no in range(num_users)]
        item_data = [item_data_dict[item_no] for item_no in range(num_items)]
        user_ids = [user_no2id[user_no] for user_no in range(num_users)]
        item_ids = [item_no2id[item_no] for item_no in range(num_items)]
        logs = IRTDataset.Logs(user_data=user_data, item_data=item_data)
        knowledges = IRTDataset.Knowledges()
        meta = IRTDataset.Meta(user_ids=user_ids, item_ids=item_ids)
        return cls(logs=logs, knowledges=knowledges, meta=meta)

    @classmethod
    def from_dataframe(cls, df: pd.DataFrame) -> "IRTDataset":  # pragma: no cover
        """build a IRT dataset with pandas dataframe

        Args:
            df (pd.DataFrame): a pandas dataframe with columns [user_id, item_id, correct]
        """
        columns = ["user_id", "item_id", "correct"]
        assert set(columns).issubset(df.columns), "The dataframe must contain columns [user_id, item_id, correct]"
        tuples = df[columns].to_records(index=False).tolist()
        return cls.from_tuples(tuples)

    @classmethod
    def from_csv(cls, file_name: str) -> "IRTDataset":  # pragma: no cover
        """build a IRT dataset from a csv file

        Args:
            file_name: path to the csv file

        Note:
            the csv file must have the following columns:
            [user_id, item_id, correct]
        """
        df = pd.read_csv(file_name)
        return cls.from_dataframe(df)

    @classmethod
    def from_dict(cls, user_data_dict: dict[str, dict[str, int]]) -> "IRTDataset":  # pragma: no cover
        tuples = itertools.chain.from_iterable(
            [(user_id, item_id, correct) for item_id, correct in data_dict.items()]
            for user_id, data_dict in user_data_dict.items()
        )
        return cls.from_tuples(list(tuples))

    @classmethod
    def from_json(cls, file_name: str) -> "IRTDataset":  # pragma: no cover
        """build a IRT dataset from a json file

        Args:
            file_name: path to the json file

        Note:
            the json file must have the following format:
            {user_id: {item_id: correct}}
        """
        with open(file_name, "r") as f:
            user_data_dict = json.load(f)
        return cls.from_dict(user_data_dict)

    def to_tuples(self) -> list[tuple[str, str, int]]:  # pragma: no cover
        tuples = itertools.chain.from_iterable(
            [
                (self.meta.user_ids[user_no], self.meta.item_ids[item_no], correct)
                for item_no, correct in user_data.items()
            ]
            for user_no, user_data in enumerate(self.logs.user_data)
        )
        return list(tuples)

    def to_dict(self) -> dict[str, dict[str, int]]:  # pragma: no cover
        user_data_dict = {
            self.meta.user_ids[user_no]: {
                self.meta.item_ids[item_no]: correct for item_no, correct in data_dict.items()
            }
            for user_no, data_dict in enumerate(self.logs.user_data)
        }
        return user_data_dict

    def to_json(self, file_name: str) -> None:  # pragma: no cover
        user_data_dict = self.to_dict()
        with open(file_name, "w") as f:
            json.dump(user_data_dict, f)

    def to_dataframe(self) -> pd.DataFrame:  # pragma: no cover
        tuples = self.to_tuples()
        return pd.DataFrame.from_records(tuples, index=None, columns=["user_id", "item_id", "correct"])

    def to_csv(self, file_name: str) -> None:  # pragma: no cover
        self.to_dataframe().to_csv(file_name)

    def add_knowledges(
        self,
        knowledge_structure: dict[str, list[str]],
        related_items: dict[str, list[str]],
    ):
        """add knowledge information after basic dataset construction

        Args:
            knowledge_structure: a dict from <knowledge_id> to a list of its successors <knowledge_id>
            related_items: a dict from <knowledge_id> to a list of its associated <item_id>

        Notes:
            all the knowledge ids should exist in `knowledge_structure`, even if they have no successor
        """
        assert len(self.meta.knowledge_ids) == 0, "Knowledge information already exists"
        knowledge_ids = list(sorted(set(knowledge_structure.keys())))
        item_ids = self.meta.item_ids

        knowledge_to_idx = {knowledge_id: idx for idx, knowledge_id in enumerate(knowledge_ids)}
        item_to_idx = {item_id: idx for idx, item_id in enumerate(item_ids)}

        knowledge_structure_reversed: dict[str, list] = {k: [] for k in knowledge_ids}
        for knowledge_id, successor_id_list in knowledge_structure.items():
            for successor_id in successor_id_list:
                knowledge_structure_reversed[successor_id].append(knowledge_id)

        related_item_lists: list[list[int]] = []
        predecessor_lists: list[list[int]] = []
        successor_lists: list[list[int]] = []
        for knowledge_id in knowledge_ids:
            related_item_lists.append(list(map(lambda x: item_to_idx[x], related_items[knowledge_id])))
            successor_lists.append(list(map(lambda x: knowledge_to_idx[x], knowledge_structure[knowledge_id])))
            predecessor_lists.append(
                list(
                    map(
                        lambda x: knowledge_to_idx[x],
                        knowledge_structure_reversed[knowledge_id],
                    )
                )
            )

        knowledges = self.Knowledges(
            related_items=related_item_lists,
            predecessors=predecessor_lists,
            successors=successor_lists,
        )

        _num_knowledge = [
            len(knowledge_ids),
            len(knowledges.related_items),
            len(knowledges.successors),
            len(knowledges.predecessors),
        ]
        assert _num_knowledge.count(_num_knowledge[0]) == len(_num_knowledge)

        self.meta.knowledge_ids = knowledge_ids
        self.knowledges = knowledges

    def statistics(self) -> Stats:
        """the statistical information of this dataset

        Returns:
            a Dataset.Stats dataclass object
        """
        num_users = len(self.meta.user_ids)
        num_items = len(self.meta.item_ids)
        num_knowledges = len(self.meta.knowledge_ids)
        num_logs_per_user = np.array([len(data) for data in self.logs.user_data])
        num_logs_per_item = np.array([len(data) for data in self.logs.item_data])
        num_logs_per_knowledge = np.array(
            [sum(num_logs_per_item[item_no] for item_no in item_nos) for item_nos in self.knowledges.related_items]
        )
        num_logs = sum(num_logs_per_user)
        num_corrects = sum(sum(data.values()) for data in self.logs.user_data)
        label_distribution = num_corrects / num_logs
        assert label_distribution <= 1.0

        stats = IRTDataset.Stats(
            n_logs=num_logs,
            n_users=num_users,
            n_items=num_items,
            n_knowledges=num_knowledges,
            n_logs_per_user_min=(num_logs_per_user.min() if num_logs_per_user.shape[0] > 0 else np.nan),
            n_logs_per_user_max=(num_logs_per_user.max() if num_logs_per_user.shape[0] > 0 else np.nan),
            n_logs_per_user_avg=(num_logs_per_user.mean() if num_logs_per_user.shape[0] > 0 else np.nan),
            n_logs_per_item_min=(num_logs_per_item.min() if num_logs_per_item.shape[0] > 0 else np.nan),
            n_logs_per_item_max=(num_logs_per_item.max() if num_logs_per_item.shape[0] > 0 else np.nan),
            n_logs_per_item_avg=(num_logs_per_item.mean() if num_logs_per_item.shape[0] > 0 else np.nan),
            n_logs_per_knowledge_min=(num_logs_per_knowledge.min() if num_logs_per_knowledge.shape[0] > 0 else np.nan),
            n_logs_per_knowledge_max=(num_logs_per_knowledge.max() if num_logs_per_knowledge.shape[0] > 0 else np.nan),
            n_logs_per_knowledge_avg=(num_logs_per_knowledge.mean() if num_logs_per_knowledge.shape[0] > 0 else np.nan),
            label_distribution=label_distribution,
        )
        return stats

    def split_by_user(
        self,
        heldout_ratio: float,
        random_seed: int = 0,
        by_length: bool = False,
    ) -> tuple["IRTDataset", "IRTDataset"]:
        """split a part of users from `dataset` as held-out users

        Args:
            heldout_ratio: (#users of held-out data) / (#users of original data)
            random_seed: control randomness while spliting
            by_length: if set true, split those users with longest logs as held-out users,
                    and `random_seed` gets invalid

        Returns:
            Two non-overlapping datasets with (1-`heldout_ratio`) and `heldout_ratio` user numbers

        Notes:
            The function renumbers users and keeps the numbering of items
        """
        assert 0 < heldout_ratio < 1
        stats: IRTDataset.Stats = self.statistics()
        logs: IRTDataset.Logs = self.logs
        num_heldout_users = int(heldout_ratio * stats.n_users)
        rand = random.Random(random_seed)
        num_remain_users = stats.n_users - num_heldout_users

        heldout_user_nos: list[int]
        if by_length:
            user_log_length_sorts = sorted(range(stats.n_users), key=lambda i: len(logs.user_data[i]), reverse=True)
            heldout_user_nos = user_log_length_sorts[:num_heldout_users]
        else:
            user_shuffle = list(range(stats.n_users))
            rand.shuffle(user_shuffle)
            heldout_user_nos = user_shuffle[:num_heldout_users]
        assert len(heldout_user_nos) == num_heldout_users

        heldout_user_nos = list(sorted(heldout_user_nos))
        remain_user_nos = list(sorted(set(range(stats.n_users)).difference(heldout_user_nos)))
        assert len(remain_user_nos) == num_remain_users
        heldout_user_nos_set = set(heldout_user_nos)
        remain_user_nos_set = set(remain_user_nos)
        heldout_user_renumber = {user_no: i for i, user_no in enumerate(heldout_user_nos)}
        remain_user_renumber = {user_no: i for i, user_no in enumerate(remain_user_nos)}

        heldout_user_data, remain_user_data = [], []
        for user_no in range(stats.n_users):
            if user_no in heldout_user_nos_set:
                heldout_user_data.append(copy.deepcopy(self.logs.user_data[user_no]))
            elif user_no in remain_user_nos_set:
                remain_user_data.append(copy.deepcopy(self.logs.user_data[user_no]))
            else:
                raise ValueError()

        heldout_item_data, remain_item_data = [], []
        for item_no, data_dict in enumerate(self.logs.item_data):
            heldout_item_data.append(
                {
                    heldout_user_renumber[user_no]: response
                    for user_no, response in data_dict.items()
                    if user_no in heldout_user_nos_set
                }
            )
            remain_item_data.append(
                {
                    remain_user_renumber[user_no]: response
                    for user_no, response in data_dict.items()
                    if user_no in remain_user_nos_set
                }
            )

        heldout_logs = IRTDataset.Logs(
            user_data=heldout_user_data,
            item_data=heldout_item_data,
        )
        remain_logs = IRTDataset.Logs(
            user_data=remain_user_data,
            item_data=remain_item_data,
        )
        heldout_meta = copy.deepcopy(self.meta)
        heldout_meta.user_ids = [self.meta.user_ids[user_no] for user_no in heldout_user_nos]
        remain_meta = copy.deepcopy(self.meta)
        remain_meta.user_ids = [self.meta.user_ids[user_no] for user_no in remain_user_nos]
        heldout_dataset = IRTDataset(
            logs=heldout_logs,
            knowledges=copy.deepcopy(self.knowledges),
            meta=heldout_meta,
        )
        remain_dataset = IRTDataset(logs=remain_logs, knowledges=copy.deepcopy(self.knowledges), meta=remain_meta)

        # checks
        heldout_stats = heldout_dataset.statistics()
        remain_stats = remain_dataset.statistics()
        assert heldout_stats.n_users + remain_stats.n_users == stats.n_users
        assert heldout_stats.n_logs + remain_stats.n_logs == stats.n_logs
        assert heldout_stats.n_items == remain_stats.n_items and heldout_stats.n_items == stats.n_items
        assert heldout_dataset.meta.item_ids == remain_dataset.meta.item_ids
        assert set(heldout_dataset.meta.user_ids).union(set(remain_dataset.meta.user_ids)) == set(self.meta.user_ids)

        return remain_dataset, heldout_dataset

    def split_by_log(
        self,
        heldout_ratio: float,
        random_seed: int = 0,
        prevent_cold_start: bool = False,
    ) -> tuple["IRTDataset", "IRTDataset"]:
        """split a part of data from `dataset` as held-out data

        Args:
            heldout_ratio: (#logs of held-out data) / (#logs of original data)
            random_seed: control randomness while spliting
            prevent_cold_start: if set True, every item shown in held-out data
                will also shown in the other part

        Returns:
            Two non-overlapping datasets of (1-`heldout_ratio`) and `heldout_ratio` size

        Notes:
            The function keeps the numbering of users and items
        """
        assert 0 < heldout_ratio < 1
        stats: IRTDataset.Stats = self.statistics()
        logs: IRTDataset.Logs = self.logs
        remain_user_data = copy.deepcopy(logs.user_data)
        remain_item_data = copy.deepcopy(logs.item_data)
        heldout_user_data: list[dict] = [dict() for _ in range(stats.n_users)]
        heldout_item_data: list[dict] = [dict() for _ in range(stats.n_items)]

        rand = random.Random(random_seed)
        fail_users = set()
        budget = int(stats.n_logs * heldout_ratio)
        for user_no, user_logs in itertools.cycle(enumerate(remain_user_data)):
            if budget <= 0:
                break
            if user_no in fail_users:
                continue
            all_items = list(user_logs.keys())
            available_items = list(
                filter(
                    lambda item_no: len(remain_item_data[item_no]) > (1 if prevent_cold_start else 0),
                    all_items,
                )
            )
            if len(available_items) <= 1:
                fail_users.add(user_no)
                if len(fail_users) >= stats.n_users:
                    raise ValueError("Fail to split")
                continue
            n_samples = max(1, int(heldout_ratio * len(all_items)))
            n_samples = min(n_samples, len(available_items), budget)
            sampled_items = rand.sample(available_items, n_samples)
            for item_no in sampled_items:
                correct = remain_user_data[user_no].pop(item_no)
                correct_ = remain_item_data[item_no].pop(user_no)
                assert correct == correct_, "inconsistency found in original data"
                heldout_user_data[user_no][item_no] = correct
                heldout_item_data[item_no][user_no] = correct
            budget -= n_samples

        if prevent_cold_start:
            assert not any(
                len(remain_user_data[user_no]) == 0 and len(heldout_user_data[user_no]) > 0
                for user_no in range(stats.n_users)
            )
            assert not any(
                len(remain_item_data[item_no]) == 0 and len(heldout_item_data[item_no]) > 0
                for item_no in range(stats.n_items)
            )

        remain_dataset = IRTDataset(
            logs=IRTDataset.Logs(user_data=remain_user_data, item_data=remain_item_data),
            knowledges=copy.deepcopy(self.knowledges),
            meta=copy.deepcopy(self.meta),
        )
        heldout_dataset = IRTDataset(
            logs=IRTDataset.Logs(user_data=heldout_user_data, item_data=heldout_item_data),
            knowledges=copy.deepcopy(self.knowledges),
            meta=copy.deepcopy(self.meta),
        )
        return remain_dataset, heldout_dataset

    def filter_users(
        self,
        n_logs_per_user_min: Optional[int] = None,
        n_logs_per_user_max: Optional[int] = None,
    ) -> "IRTDataset":  # pragma: no cover
        """Filter users by requiring mininum and/or maximum associated #logs"""
        logs = self.logs
        meta = self.meta
        user_data = copy.deepcopy(logs.user_data)
        user_ids = meta.user_ids
        item_ids = meta.item_ids

        filtered_user_nos = list(range(len(user_data)))
        if n_logs_per_user_min is not None:
            filtered_user_nos = [i for i in filtered_user_nos if len(user_data[i]) >= n_logs_per_user_min]
        if n_logs_per_user_max is not None:
            filtered_user_nos = [i for i in filtered_user_nos if len(user_data[i]) <= n_logs_per_user_max]
        assert len(filtered_user_nos) > 0, "No user left"

        filtered_tuples = list(
            itertools.chain.from_iterable(
                [(user_ids[user_no], item_ids[item_no], correct) for item_no, correct in user_data[user_no].items()]
                for user_no in filtered_user_nos
            )
        )
        filtered_dataset = IRTDataset.from_tuples(filtered_tuples)
        return filtered_dataset

    def filter_items(
        self,
        n_logs_per_item_min: Optional[int] = None,
        n_logs_per_item_max: Optional[int] = None,
    ) -> "IRTDataset":  # pragma: no cover
        """Filter items by requiring mininum and/or maximum associated #users"""
        logs = self.logs
        meta = self.meta
        item_data = copy.deepcopy(logs.item_data)
        user_ids = meta.user_ids
        item_ids = meta.item_ids

        filtered_item_nos = list(range(len(item_data)))
        if n_logs_per_item_min is not None:
            filtered_item_nos = [i for i in filtered_item_nos if len(item_data[i]) >= n_logs_per_item_min]
        if n_logs_per_item_max is not None:
            filtered_item_nos = [i for i in filtered_item_nos if len(item_data[i]) <= n_logs_per_item_max]
        assert len(filtered_item_nos) > 0, "No item left"

        filtered_tuples = list(
            itertools.chain.from_iterable(
                [(user_ids[user_no], item_ids[item_no], correct) for user_no, correct in item_data[item_no].items()]
                for item_no in filtered_item_nos
            )
        )
        filtered_dataset = IRTDataset.from_tuples(filtered_tuples)
        return filtered_dataset
