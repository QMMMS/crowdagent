from __future__ import annotations

import math
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from crowdlib.quality.confidence.classification.util import get_avg_worker_error_matrix


@dataclass
class SingleChoiceBayesInference:
    r"""
    单选题贝叶斯推理：用于N选1题目根据用户水平和当前题目选项的先验概率得到选项的后验概率。

    下面通过一个三选一的例子来说明算法原理:
    设三个选项为: 0, 1, 2，设$T$为真值，每个选项的先验概率分别为
    $P(T=0) = \frac{1}{3}$, $P(T=1) = \frac{1}{3}$, $P(T=2) = \frac{1}{3}$

    第一个工人$W_1$开始标注，他选择了选项 0，他的准确率为 0.8(准确率是从他历史的答题结果加权平均得到)，
    我们将他的准确率转换为混淆矩阵(将错误率均摊到其他选项上):

    $$
    \begin{bmatrix}
    P(W_1 = 0 | T=0)=0.8 & P(W_1 = 0 | T=1)=0.1 & P(W_1 = 0 | T=2)=0.1 \\
    P(W_1 = 1 | T=0)=0.1 & P(W_1 = 1 | T=1)=0.8 & P(W_1 = 1 | T=2)=0.1 \\
    P(W_1 = 2 | T=0)=0.1 & P(W_1 = 2 | T=1)=0.1 & P(W_1 = 2 | T=2)=0.8 \\
    \end{bmatrix}
    $$

    我们计算$W_1$标注之后各个选项的后验概率:

    $$
    \begin{align*}
    P(T=0 | W_1 = 0) &= \frac{P(W_1 = 0 | T=0) P(T=0)}{P(W_1 = 0)} \\
    &= \frac{P(W_1 = 0 | T=0) P(T=0)}{P(W_1 = 0 | T=0) P(T=0) + P(W_1 = 0 | T=1) P(T=1) + P(W_1 = 0 | T=2) P(T=2)} \\
    &= \frac{0.8 \times \frac{1}{3}}{0.8 \times \frac{1}{3} + 0.1 \times \frac{1}{3} + 0.1 \times \frac{1}{3}} \\
    &= 0.8 \\
    \end{align*}
    $$

    同理，可以算出另外两个选项的后验概率:

    $$
    P(T=1 | W_1 = 0) = 0.1
    $$

    $$
    P(T=2 | W_1 = 0) = 0.1
    $$

    此时各个选项的后验概率为: $P(T=0) = 0.8$, $P(T=1) = 0.1$, $P(T=2) = 0.1$.
    这就是一次完整的贝叶斯推理。之后的每次标注都是用同样的方法来更新后验概率。
    不同的是，之后**每次更新的先验概率都是上次的后验概率**。

    然后第二个工人$W_2$开始标注，此时各个选项的先验概率为$P(T=0) = 0.8$, $P(T=1) = 0.1$, $P(T=2) = 0.1$.
    $W_2$也选择了选项 0，他的准确率为 0.9,我们同样将他的准确率转换为混淆矩阵:

    $$
    \begin{bmatrix}
    P(W_1 = 0 | T=0)=0.9 & P(W_1 = 0 | T=1)=0.05 & P(W_1 = 0 | T=2)=0.05 \\
    P(W_1 = 1 | T=0)=0.05 & P(W_1 = 1 | T=1)=0.9 & P(W_1 = 1 | T=2)=0.05 \\
    P(W_1 = 2 | T=0)=0.05 & P(W_1 = 2 | T=1)=0.05 & P(W_1 = 2 | T=2)=0.9 \\
    \end{bmatrix}
    $$

    我们计算$W_2$标注之后各个选项的后验概率:

    $$
    \begin{align*}
    P(T=0 | W_2 = 0) &= \frac{P(W_2 = 0 | T=0) P(T=0)}{P(W_2 = 0)} \\
    &= \frac{P(W_2 = 0 | T=0) P(T=0)}{P(W_2 = 0 | T=0) P(T=0) + P(W_2 = 0 | T=1) P(T=1) + P(W_2 = 0 | T=2) P(T=2)} \\
    &= \frac{0.9 \times 0.8}{0.9 \times 0.8 + 0.05 \times 0.1 + 0.05 \times 0.1} \\
    &= \frac{0.72}{0.73} \\
    &= 0.9863013698630136 \\
    \end{align*}
    $$

    同理，可以算出另外两个选项的后验概率:

    $$
    P(T=1 | W_2 = 0) = 0.006849315068493146
    $$

    $$
    P(T=2 | W_2 = 0) = 0.006849315068493146
    $$

    此时各个选项的后验概率为: $P(T=0) \approx 0.9863$, $P(T+1) \approx 0.0068$, $P(T=2) \approx 0.0068$.

    Note:
        - 如果题目置信度阈值为 $0.95$, $0.9863 > 0.95$, 此时认为该题目收敛，题目结束标注，推断出的真值是选项 0。
        - 如果题目置信度阈值为 $0.999$, $0.9863 < 0.999$, 此时认为该题目未收敛，题目会继续被标注。


    我们可以通过下面的代码来验证上述计算过程:

    Examples:
        >>> from crowdlib.quality.confidence.classification.bayes import SingleChoiceBayesInference
        >>> bayes = SingleChoiceBayesInference(num_choices=3)
        >>> choice_probas = bayes.fit_predict_prob(worker_choice=0, worker_accuracy=0.8)
        >>> print(round(choice_probas[0], 4), round(choice_probas[1], 4), round(choice_probas[2], 4))
        0.8 0.1 0.1
        >>> choice_probas = bayes.fit_predict_prob(worker_choice=0, worker_accuracy=0.9)
        >>> print(round(choice_probas[0], 4), round(choice_probas[1], 4), round(choice_probas[2], 4))
        0.9863 0.0068 0.0068


    下面给出有无选项的先验概率时的使用示例。

    在无选项的先验概率时:

    Examples:
        >>> from crowdlib.quality.confidence.classification.bayes import SingleChoiceBayesInference
        >>> bayes = SingleChoiceBayesInference(num_choices=2)
        >>> choice_probas = bayes.fit_predict_prob(worker_choice=0, worker_accuracy=0.8)
        >>> round(choice_probas[0], 1)
        0.8
        >>> round(choice_probas[1], 1)
        0.2

    在有选项的先验概率时:

    Examples:
        >>> from crowdlib.quality.confidence.classification.bayes import SingleChoiceBayesInference
        >>> bayes = SingleChoiceBayesInference(num_choices=3, choices_prior={0: 0.1, 1: 0.2, 2: 0.7})
        >>> choice_probas = bayes.fit_predict_prob(worker_choice=2, worker_accuracy=0.6)
        >>> round(choice_probas[0], 3)
        0.042
        >>> round(choice_probas[1], 3)
        0.083
        >>> round(choice_probas[2], 3)
        0.875
    """

    num_choices: int
    """选项个数"""
    choices_prior: dict[int, float] = field(default_factory=dict)
    """各选项的先验概率. 如`{0: 0.5, 1: 0.5}`"""
    choices_proba_: dict[int, float] = field(default_factory=dict)
    """各选项当前的概率分布. 如`{0: 0.9, 1: 0.1}`"""

    def __post_init__(self):
        self.__input_validate()
        # 如果没有提供先验概率，则默认均匀分布
        if len(self.choices_prior) == 0:
            self.choices_prior = {i: 1 / self.num_choices for i in range(self.num_choices)}
        # 初始时的概率分布就是先验分布
        self.choices_proba_ = deepcopy(self.choices_prior)

    @property
    def choices(self) -> list[int]:
        return list(range(self.num_choices))

    def fit(
        self,
        worker_choice: int,
        worker_accuracy: Optional[float] = None,
        worker_error_matrix: Optional[dict[int, dict[int, float]]] = None,
    ) -> "SingleChoiceBayesInference":
        """
        根据工人的标注和准确率，计算后验概率。每次执行`fit`都会更新`choices_proba_`。

        Note:
            注意`worker_error_matrix` 和`worker_accuracy`只能提供一个。
            当提供`worker_accuracy`时，会根据准确率计算混淆矩阵，如当工人的准确率为 0.8,
            内部计算时其准确率混淆矩阵为:

            ```python
            {
                0: {0: 0.8, 1: 0.1, 2: 0.1},
                1: {0: 0.1, 1: 0.8, 2: 0.1},
                2: {0: 0.1, 1: 0.1, 2: 0.8}
            }
            ```
            第一行表示当真值为 0 时，工人选择 0 的概率为 0.8，选择 1 的概率为 0.1，选择 2 的概率为 0.1，其他行同理。

            除了准确率外，还可以提供工人的混淆矩阵，格式和上面一样。

        Args:
            worker_choice: 工人的标注
            worker_accuracy: 工人的准确率
            worker_error_matrix: 工人的混淆矩阵

        Returns:
            Self.
        """
        error_matrix = self._get_worker_error_matrix(worker_accuracy, worker_error_matrix)
        self._update_choices_proba(worker_choice, error_matrix)
        return self

    def fit_predict_prob(
        self,
        worker_choice: int,
        worker_accuracy: Optional[float] = None,
        worker_error_matrix: Optional[dict[int, dict[int, float]]] = None,
    ) -> dict[int, float]:
        """
        根据工人的标注和准确率(或混淆矩阵)，计算后验概率。每次执行`fit_predict_prob`都会更新`choices_proba_`。

        Note:
            注意`worker_error_matrix` 和`worker_accuracy`只能提供一个。
            当提供`worker_accuracy`时，会根据准确率计算混淆矩阵，如当工人的准确率为 0.8,
            内部计算时其准确率混淆矩阵为:

            ```python
            {
                0: {0: 0.8, 1: 0.1, 2: 0.1},
                1: {0: 0.1, 1: 0.8, 2: 0.1},
                2: {0: 0.1, 1: 0.1, 2: 0.8}
            }
            ```
            第一行表示当真值为 0 时，工人选择 0 的概率为 0.8，选择 1 的概率为 0.1，选择 2 的概率为 0.1，其他行同理。

            除了准确率外，还可以提供工人的混淆矩阵，格式和上面一样。

        Args:
            worker_choice: 工人的标注
            worker_accuracy: 工人的准确率
            worker_error_matrix: 工人的混淆矩阵

        Returns:
            各选项的后验分布
        """
        return self.fit(worker_choice, worker_accuracy, worker_error_matrix).choices_proba_

    def _update_choices_proba(self, worker_choice: int, worker_error_matrix: dict[int, dict[int, float]]):
        # 计算各选项的后验分布: 将当前选项的概率分布作为先验分布，结合worker答题信息用贝叶斯公式算出其后验分布作为新的选项分布
        choice_priors = deepcopy(self.choices_proba_)
        for choice, prior_prob in choice_priors.items():
            # P(worker=worker_choice, truth=choice) = P(worker=worker_choice | truth=choice) * P(truth=choice)
            nominator = worker_error_matrix[choice][worker_choice] * prior_prob
            # P(truth=choice): 全概率公式
            probas = [
                worker_error_matrix[dummy_choice][worker_choice] * choice_priors[dummy_choice]
                for dummy_choice in choice_priors.keys()
            ]
            denominator = sum(probas)
            # P(truth=choice | worker=worker_choice) = P(worker=worker_choice, truth=choice) / P(truth=choice)
            posterior_prob = nominator / denominator
            self.choices_proba_[choice] = posterior_prob

    def _get_worker_error_matrix(
        self,
        worker_accuracy: Optional[float] = None,
        worker_error_matrix: Optional[dict[int, dict[int, float]]] = None,
    ) -> dict[int, dict[int, float]]:
        if worker_error_matrix is not None:
            if worker_accuracy is not None:
                # can not provide both
                raise ValueError("Either worker_accuracy or worker_error_matrix should be provided, now got both.")

        if worker_error_matrix is not None:
            # truth/predict keys should equal with choices
            if set(worker_error_matrix.keys()) != set(self.choices):
                raise ValueError(f"Invalid error matrix: truth labels not equal with {self.choices}")
            for prob_dist in worker_error_matrix.values():
                if set(prob_dist.keys()) != set(self.choices):
                    raise ValueError(f"Invalid error matrix: predict labels not equal with {self.choices}")

            for truth in worker_error_matrix.keys():
                # check it's valid confusion matrix, all rows should sum to 1
                if not math.isclose(sum(worker_error_matrix[truth].values()), 1):
                    raise ValueError(
                        f"The sum of values in worker_error_matrix should be close to 1. "
                        f"Got {sum(worker_error_matrix[truth].values())} instead."
                    )
                # all values should in [0, 1]
                for worker_label in worker_error_matrix[truth].keys():
                    if not (0 <= worker_error_matrix[truth][worker_label] <= 1):
                        raise ValueError(
                            f"The values of worker_error_matrix should be in [0, 1]. "
                            f"Got {worker_error_matrix[truth][worker_label]} instead."
                        )
            # clip to [eps, 1-eps]
            eps = 1e-10
            for truth in worker_error_matrix.keys():
                for worker_label in worker_error_matrix[truth].keys():
                    worker_error_matrix[truth][worker_label] = np.clip(
                        worker_error_matrix[truth][worker_label], eps, 1 - eps
                    ).item()

            return worker_error_matrix
        # 如果没有提供混淆矩阵，则根据准确率计算混淆矩阵
        elif worker_accuracy is not None:
            # 根据准确率获取用户的混淆矩阵
            worker_error_matrix = get_avg_worker_error_matrix(self.num_choices, worker_accuracy)
            return worker_error_matrix
        else:
            raise ValueError("Either worker_accuracy or worker_error_matrix should be provided, now got none.")

    def __input_validate(self):
        if self.num_choices <= 1:
            raise ValueError(f"The num_choices should be greater than 1. Got {self.num_choices} instead.")
        if len(self.choices_prior) != 0:
            if len(self.choices_prior) != self.num_choices:
                raise ValueError(
                    f"The length of choices_prior should be equal to num_choices. "
                    f"Got {len(self.choices_prior)} instead."
                )
            if set(self.choices_prior.keys()) != set(range(self.num_choices)):
                raise ValueError(
                    f"The keys of choices_prior should be {set(range(self.num_choices))}. "
                    f"Got {self.choices_prior.keys()} instead."
                )
            if not all(0 <= p <= 1 for p in self.choices_prior.values()):
                raise ValueError("All values in choices_prior should be between 0 and 1.")
            if not math.isclose(sum(self.choices_prior.values()), 1):
                raise ValueError("The sum of values in choices_prior should be close to 1.")
