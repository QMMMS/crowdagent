from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from torch.func import functional_call
from torch.utils.data import DataLoader
from tqdm import tqdm

from crowdlib.learn.irt.config import EvaluatorConfig
from crowdlib.learn.irt.dataset import IRTDataset, IRTLogDataset
from crowdlib.learn.irt.net import HierarchicalItemResponseTheoryNet


class Evaluator:
    def __init__(self, cfg: EvaluatorConfig, device: str):
        # basic configuration
        self.device = device
        self.batch_size = cfg.batch_size

    def evaluate(
        self, data: IRTDataset, model: HierarchicalItemResponseTheoryNet, user_params: dict[str, nn.Parameter]
    ) -> tuple[dict, dict]:
        val_dataset = IRTLogDataset(data)
        val_dataloader = DataLoader(
            val_dataset,
            batch_size=self.batch_size,
        )
        all_preds = []
        all_labels = []
        model.eval()
        with torch.no_grad():
            for batch in tqdm(val_dataloader):
                user_nos, item_nos, labels = batch
                user_nos = user_nos.long().to(self.device)
                item_nos = item_nos.long().to(self.device)
                preds = functional_call(
                    model,
                    {k: p[user_nos] for k, p in user_params.items()},
                    args=(item_nos,),
                )
                labels = labels.cpu().numpy().tolist()
                preds = preds.detach().cpu().numpy().tolist()
                all_labels.extend(labels)
                all_preds.extend(preds)
        model.train()
        all_preds_np = np.array(all_preds)
        all_labels_np = np.array(all_labels)
        all_bin_preds_np = np.where(all_preds_np > 0.5, 1, 0)
        acc = accuracy_score(all_labels_np, all_bin_preds_np)
        auc = roc_auc_score(all_labels_np, all_preds_np)
        f1 = f1_score(all_labels_np, all_bin_preds_np)
        loss = nn.BCELoss()(
            torch.from_numpy(all_preds_np).double().to(self.device),
            torch.from_numpy(all_labels_np).double().to(self.device),
        )
        results = {"acc": acc, "auc": auc, "f1": f1, "loss": loss}
        return results, {}
