from __future__ import annotations

from torch.utils.data import Dataset as TorchDataset

from .base import IRTDataset


class IRTLogDataset(TorchDataset):
    r"""A wrapper class for `IRTDataset` to facilitate mini-batch training"""

    def __init__(self, data_obj: IRTDataset):
        super().__init__()
        self.user_data = data_obj.logs.user_data
        self.item_data = data_obj.logs.item_data

        stats = data_obj.statistics()
        self.num_users = stats.n_users
        self.num_items = stats.n_items
        self.num_knowledge = stats.n_knowledges
        self.num_logs = stats.n_logs
        self.user_no2id = data_obj.meta.user_ids
        self.item_no2id = data_obj.meta.item_ids
        self.knowledge_no2id = data_obj.meta.knowledge_ids

        self.log_data = []
        for user_no, user_logs in enumerate(self.user_data):
            for item_no, correct in user_logs.items():
                self.log_data.append((user_no, item_no, correct))

    def __len__(self):
        return len(self.log_data)

    def __getitem__(self, item):
        return self.log_data[item]
