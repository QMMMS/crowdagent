"""
Some modification by <liuhaoyu03@corp.netease.com>: for non-fully ranked scenario
The code is mainly copied from statsmodels: https://github.com/statsmodels/statsmodels/blob/cfd370fc42f5d8cac05678850007d81d4cf91c1a/statsmodels/stats/inter_rater.py#L194
"""

from __future__ import annotations

import numpy as np


def fleiss_kappa(table: np.ndarray) -> float:
    """Fleiss' and Randolph's kappa multi-rater agreement measure

    Args:
        table: array_like, 2-D, subjects in rows, and categories in columns.

    Returns:
        kappa: Fleiss's Kappa results

    Notes:
        No variance or hypothesis tests yet.

        Interrater agreement measures like Fleiss's kappa measure agreement relative
        to chance agreement. Different authors have proposed ways of defining
        these chance agreements. Fleiss' is based on the marginal sample distribution
        of categories, while Randolph uses a uniform distribution of categories as
        benchmark. Warrens (2010) showed that Randolph's kappa is always larger or
        equal to Fleiss' kappa. Under some commonly observed condition, Fleiss' and
        Randolph's kappa provide lower and upper bounds for two similar kappa_like
        measures by Light (1971) and Hubert (1977).

        Wikipedia https://en.wikipedia.org/wiki/Fleiss%27_kappa

        Fleiss, Joseph L. 1971. "Measuring Nominal Scale Agreement among Many
        Raters." Psychological Bulletin 76 (5): 378-82.
        https://doi.org/10.1037/h0031619.

        Randolph, Justus J. 2005 "Free-Marginal Multirater Kappa (multirater
        K [free]): An Alternative to Fleiss' Fixed-Marginal Multirater Kappa."
        Presented at the Joensuu Learning and Instruction Symposium, vol. 2005
        https://eric.ed.gov/?id=ED490661

        Warrens, Matthijs J. 2010. "Inequalities between Multi-Rater Kappas."
        Advances in Data Analysis and Classification 4 (4): 271-86.
        https://doi.org/10.1007/s11634-010-0073-4.


    Fleiss' Kappa can also be used for non-fully ranked tables

    Note:
        To use Fleiss' Kappa with variable numer of raters, calculate the
        observed agreement for every subject with independent rater number.


        Jeffrey Girard (https://stats.stackexchange.com/users/111380/jeffrey-girard),
        Kappa Statistic for Variable Number of Raters,
        URL (version: 2017-01-03): https://stats.stackexchange.com/q/254253

        MichaelU (https://stats.stackexchange.com/users/249968/michaelu),
        Inter-rater agreement for non-fully crossed designs,
        URL (version: 2019-06-05): https://stats.stackexchange.com/q/411624

        Hallgren KA. Computing Inter-Rater Reliability for Observational Data: An
        Overview and Tutorial. Tutor Quant Methods Psychol. 2012;8(1):23-34.
        doi: 10.20982/tqmp.08.1.p023. PMID: 22833776; PMCID: PMC3402032.
        https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3402032/#!po=50.0000
    """
    table = 1.0 * np.asarray(table)  # avoid integer division
    n_sub, n_cat = table.shape
    n_total = table.sum()  # total rates
    n_rates = table.sum(axis=1)  # count rates at each row
    n_rat = n_rates.max()

    # assume non-fully ranked
    assert n_total != 0, "Empty table"
    assert n_total <= n_sub * n_rat, "Check total rates count"
    # marginal frequency  of categories
    p_cat = table.sum(axis=0) / n_total
    table2 = table * table
    # for non-fully ranked scenario
    p_rat = (table2.sum(1) - n_rates) / (n_rates * (n_rates - 1.0))
    p_mean = p_rat.mean()
    if np.isclose(p_mean, 1.0):
        # avoid returning NaN kappa when full agreement is reached
        return 1.0

    p_mean_exp = (p_cat * p_cat).sum()
    kappa = (p_mean - p_mean_exp) / (1 - p_mean_exp)
    return kappa
