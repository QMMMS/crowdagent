from __future__ import annotations

import logging
import pathlib
from typing import Optional

from crowdlib.learn.base import LearnModel
from crowdlib.learn.irt.config import IRTConfig
from crowdlib.learn.irt.dataset import IRTDataset as IRTDataset
from crowdlib.learn.irt.net import HierarchicalItemResponseTheoryNet
from crowdlib.learn.irt.trainer import IRTTrainer, IRTTrainResult

logger = logging.getLogger(__name__)


class IRTModel(LearnModel):
    r"""The **Item Response Theory** (IRT) model is a classic cognitive diagnosis model parametrizing user's ability level and item's difficulty level.

    This class provides a hierarchical variant of the original IRT model, namelt HIRT.
    Instead of a single ability parameter for each user, we obtain one parameter on each node in the pre-built hierarchy.

    For more model detail, refer to `HierarchicalItemResponseTheoryNet`.
    """

    def __init__(self, cfg: IRTConfig = IRTConfig()):
        self.cfg = cfg
        self.device = self.cfg.device
        logger.info(self.cfg)

        self._train_result: Optional[IRTTrainResult] = None

    def train(self, data: IRTDataset) -> Optional[dict]:
        train_data = data
        net = HierarchicalItemResponseTheoryNet({"data": train_data, "device": self.device}).to(self.device)
        trainer = IRTTrainer(self.cfg.trainer, self.device)
        result, val_metrics = trainer.fit(data, net)
        self._train_result = result
        return val_metrics

    def model_load(self, model_file_path: pathlib.Path) -> LearnModel:
        raise NotImplementedError

    def model_save(self, model_file_path: pathlib.Path):
        raise NotImplementedError

    def get_train_result(self) -> IRTTrainResult:
        if self._train_result is None:
            raise RuntimeError("No train result: the model has not been trained yet")
        return self._train_result
