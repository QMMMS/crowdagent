from .interval import NumericStudentTInterval

__all__ = ["NumericStudentTInterval"]
