import numpy as np
import scipy as sp


class NumericStudentTInterval:
    """使用t分布计算数值型数据的置信区间。

    当总体标准差未知且样本量较小时，使用学生t分布来计算置信区间是合适的。
    该类实现了基于t分布的置信区间计算。

    置信区间的计算公式为：
        样本均值 ± t临界值 * (样本标准差 / sqrt(样本大小))

    Examples:
        >>> # 计算95%置信区间
        >>> from crowdlib.quality.confidence.numeric import NumericStudentTInterval
        >>> interval = NumericStudentTInterval()
        >>> numbers = [4.5, 5.2, 4.8, 5.1, 4.9, 5.3, 4.7, 5.0]
        >>> lower, upper = interval.fit(numbers, confidence=0.95)
        >>> print(f"95%置信区间: [{lower:.3f}, {upper:.3f}]")
        95%置信区间: [4.714, 5.161]
    """

    def fit(self, numbers: list[float], confidence: float) -> tuple[float, float]:
        """
        使用给定的数据计算置信区间。

        Args:
            numbers: 数值型数据列表
            confidence: 置信水平，范围在0到1之间

        Returns:
            tuple[float, float]: 置信区间的下界和上界
        """
        numbers_array = np.array(numbers)
        sample_size = len(numbers_array)
        sample_mean = float(np.mean(numbers_array))
        sample_std = float(np.std(numbers_array, ddof=1))  # ddof=1 for sample standard deviation

        t_val = sp.stats.t.ppf((1 + confidence) / 2, sample_size - 1)
        margin_of_error = t_val * (sample_std / np.sqrt(sample_size))
        lower_bound = sample_mean - margin_of_error
        upper_bound = sample_mean + margin_of_error
        return lower_bound, upper_bound
