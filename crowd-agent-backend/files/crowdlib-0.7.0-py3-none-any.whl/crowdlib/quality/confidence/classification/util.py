from __future__ import annotations

import numpy as np


def get_avg_worker_error_matrix(num_choices: int, worker_accuracy: float) -> dict[int, dict[int, float]]:
    """
    将用户的准确率转化为混淆矩阵
    """
    if num_choices <= 1:
        raise ValueError(f"num_choices 必须大于 1，当前值为 {num_choices} ")
    if not (0 <= worker_accuracy <= 1):
        raise ValueError(f"accuracy 必须在 [0, 1] 范围内，当前值为 {worker_accuracy}")

    # clip worker accuracy
    eps = 1e-10
    worker_accuracy = np.clip(worker_accuracy, eps, 1 - eps).item()  # 转换回python float
    # 错误率均摊到其他选项上
    worker_error_rate = (1 - worker_accuracy) / (num_choices - 1)
    worker_error_matrix: dict[int, dict[int, float]] = {}

    for truth in range(num_choices):
        worker_error_matrix[truth] = {}
        for worker_label in range(num_choices):
            if truth != worker_label:
                worker_error_matrix[truth][worker_label] = worker_error_rate
            else:
                worker_error_matrix[truth][worker_label] = worker_accuracy

    return worker_error_matrix
